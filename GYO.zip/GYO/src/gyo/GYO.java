/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gyo;

import it.unitn.disi.stefanomodenese.Alfabeto;
import it.unitn.disi.stefanomodenese.Hypergraph;
import it.unitn.disi.stefanomodenese.JDBC;
import it.unitn.disi.stefanomodenese.JoinTree;
import it.unitn.disi.stefanomodenese.JoinTree2;
import it.unitn.disi.stefanomodenese.Node;
import it.unitn.disi.stefanomodenese.Tabella;
import it.unitn.disi.stefanomodenese.Vertex;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.function.Consumer;
import java.util.logging.Level;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.ExpressionVisitorAdapter;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.StatementVisitorAdapter;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectBody;
import net.sf.jsqlparser.statement.select.SelectVisitorAdapter;

import java.util.logging.Logger;
import net.sf.jsqlparser.expression.BinaryExpression;
import net.sf.jsqlparser.expression.operators.relational.ComparisonOperator;
import net.sf.jsqlparser.expression.operators.relational.InExpression;
import net.sf.jsqlparser.expression.operators.relational.LikeExpression;
import net.sf.jsqlparser.parser.SimpleNode;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.FromItemVisitorAdapter;
import net.sf.jsqlparser.statement.select.SelectItem;
import net.sf.jsqlparser.statement.select.SubSelect;
import net.sf.jsqlparser.util.TablesNamesFinder;
import org.apache.commons.collections15.multimap.MultiHashMap;
import org.apache.commons.collections15.map.MultiKeyMap;

/**
 *
 * @author stefanomodenese
 */
public class GYO {
    
    static final Logger LOGGER = Logger.getLogger(GYO.class.getName());
    static ArrayList tabelle = new ArrayList();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JSQLParserException {
        
        /*Hypergraph hyper = new Hypergraph();
        hyper.addVertex("A");
        hyper.addVertex("B");
        hyper.addVertex("C");
        hyper.addVertex("D");
        hyper.addVertex("E");
        hyper.addVertex("F");
        
        hyper.addEdge2("A", "E", "F");
        hyper.addEdge2("A", "B", "C");
        hyper.addEdge2("A", "E", "C");
        hyper.addEdge2("C", "D", "E");
        
        //hyper.printList(hyper.getAdjVertices("B"));
        //System.out.println(hyper.getEdges());
        //hyper.findEar();
        
        Hypergraph hyper2 = new Hypergraph();
        hyper2.addVertex("A");
        hyper2.addVertex("B");
        hyper2.addVertex("C");
        
        hyper2.addEdge2("A", "B");
        hyper2.addEdge2("A", "C");
        hyper2.addEdge2("B", "C");
        
        //hyper2.findEar();
        //hyper2.GYOAlgo();
        
        Hypergraph hyper3 = new Hypergraph();
        hyper3.addVertex("A");
        hyper3.addVertex("B");
        hyper3.addVertex("C");
        hyper3.addVertex("D");
        hyper3.addVertex("E");
        hyper3.addVertex("F");
        hyper3.addVertex("G");
        
        hyper3.addEdge2("A", "B", "C");
        hyper3.addEdge2("B", "F");
        hyper3.addEdge2("B", "C", "D");
        hyper3.addEdge2("C", "D", "E");
        hyper3.addEdge2("D", "E", "G");
        
        //hyper3.findEar();
        //hyper.GYOAlgo();
        
        Hypergraph hyper3 = new Hypergraph();
        hyper3.addVertex("A");
        hyper3.addVertex("B");
        hyper3.addVertex("C");
        hyper3.addVertex("D");
        hyper3.addVertex("E");
        hyper3.addVertex("F");
        hyper3.addVertex("G");
        
        hyper3.addEdge2("A", "B", "C");
        hyper3.addEdge2("C", "D", "E");
        hyper3.addEdge2("E", "F", "G");
        hyper3.addEdge2("G", "A");
        
        //hyper3.findEar();
        //hyper.GYOAlgo();
        
        ArrayList results = (ArrayList)hyper3.GYOAlgo();
        //JoinTree join = (JoinTree)hyper3.GYOAlgo().get(1);
        JoinTree join = (JoinTree)results.get(1);
        Node root = (Node)results.get(2);
        //Node root = (Node)hyper3.GYOAlgo().get(2);
        //System.out.println("la radice è: "+root);
        join.BFS(join, root);
        
        //Node root = join2.getNode(new Node("A", "B", "C"));
        //System.out.println(root.getNode()+" è root? "+root.isRoot());
        //List<String> edge = new ArrayList();
        //edge.add("C");
        //edge.add("D");
        //edge.add("E");
        //Node root = new Node(edge);
        //join.BFS(join, root);
        
        /*List<String> edge1 = new ArrayList();
        edge1.add("A");
        edge1.add("B");
        edge1.add("C");
        Node nodo1 = new Node(edge1);
        
        List<String> edge2 = new ArrayList();
        edge2.add("A");
        edge2.add("B");
        edge2.add("C");
        Node nodo2 = new Node(edge2);
        
        if (nodo1.equals(nodo2)) {
        System.out.println("i due nodi sono uguali, seppur in memory locations differenti");
        }
        else {
        System.out.println("i due nodi sono ancora diversi");
        }*/
        
        // esempio di query aciclica
        //String sqlStr = "SELECT R.a, S.a FROM R,S,T WHERE R.a = S.b AND S.b = T.a";
        // esempio di query ciclica
        String sqlStr = "SELECT MIN(r.a) AS ra, MIN(s.a) AS sa FROM R AS r, S as s, T AS t WHERE r.b = s.a AND s.b = t.b AND t.a = r.a";
        // nostro esempio
        String sqlStr2 = "SELECT R.a, S.a FROM R,S,T WHERE R.a = S.b AND S.b = T.a AND T.b = 'Marco' AND T.b = R.b";
        // esempio normale
        //String sqlStr = "SELECT R.s, S.s FROM R,S,T WHERE R.a = S.b AND S.b = T.a AND T.b = 'Marco'";
        //String sqlStr = "SELECT Studenti.nome, Pagelle.ita FROM Studenti, Pagelle WHERE Studenti.id = Pagelle.id";
        // query 4b - aciclica
        String sqlStr4b = "SELECT mi_idx.info, t.title FROM it, k, mi_idx, mk, t WHERE it.info = mi_idx.info AND t.id = mi_idx.movie_id AND t.id = mk.movie_id AND mk.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it.id = mi_idx.info_type_id";
        //Statement statement = CCJSqlParserUtil.parse(sqlStr4b);
        // query 12c - aciclica
        String sqlStr12c = "SELECT cn.name, mi_idx.info, t.title FROM cn, ct, it1, it2, mc, mi, mi_idx, t WHERE cn.country_code  = '[us]' AND ct.kind  = 'production companies' AND it1.info = 'genres' AND it2.info = mi_idx.info AND t.id = mi.movie_id AND t.id = mi_idx.movie_id AND mi.info_type_id = it1.id AND mi_idx.info_type_id = it2.id AND t.id = mc.movie_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id AND mc.movie_id = mi.movie_id AND mc.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id";
        // query 22 a - aciclica
        String sqlStr22a = "SELECT cn.name, mi_idx.info, t.title FROM cn, ct, it1, it2, k, kt, mc, mi, mi_idx, mk, t WHERE it1.info  = 'countries' AND it2.info  = mi_idx.info AND kt.id = t.kind_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mi_idx.movie_id AND t.id = mc.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mi_idx.movie_id AND mk.movie_id = mc.movie_id AND mi.movie_id = mi_idx.movie_id AND mi.movie_id = mc.movie_id AND mc.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id AND mc.note like '%(200%)%' ";
        // query 29 b - aciclica
        String sqlStr29b = "SELECT chn.name, n.name, t.title FROM an, cc, cct1, cct2, chn, ci, cn, it, it3, k, mc, mi, mk, n, pi, rt, t WHERE cct1.kind  ='cast' AND cct2.kind  ='complete+verified' AND chn.name  = 'Queen' AND cn.country_code ='[us]' AND it.info  = 'release dates' AND it3.info  = 'height' AND k.keyword  = 'computer-animation' AND n.gender ='f' AND rt.role ='actress' AND t.title  = 'Shrek 2' AND t.id = mi.movie_id AND t.id = mc.movie_id AND t.id = ci.movie_id AND t.id = mk.movie_id AND t.id = cc.movie_id AND mc.movie_id = ci.movie_id AND mc.movie_id = mi.movie_id AND mc.movie_id = mk.movie_id AND mc.movie_id = cc.movie_id AND mi.movie_id = ci.movie_id AND mi.movie_id = mk.movie_id AND mi.movie_id = cc.movie_id AND ci.movie_id = mk.movie_id AND ci.movie_id = cc.movie_id AND mk.movie_id = cc.movie_id AND cn.id = mc.company_id AND it.id = mi.info_type_id AND n.id = ci.person_id AND rt.id = ci.role_id AND n.id = an.person_id AND ci.person_id = an.person_id AND chn.id = ci.person_role_id AND n.id = pi.person_id AND ci.person_id = pi.person_id AND it3.id = pi.info_type_id AND k.id = mk.keyword_id AND cct1.id = cc.subject_id AND cct2.id = cc.status_id";
        // query 17 e - aciclica
        String sqlStr17e = "SELECT n.name FROM ci, cn, k, mc, mk, n, t WHERE cn.country_code ='[us]' AND k.keyword ='character-name-in-title' AND n.id = ci.person_id AND ci.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_id = cn.id AND ci.movie_id = mc.movie_id AND ci.movie_id = mk.movie_id AND mc.movie_id = mk.movie_id";
        // query 14 b - aciclica
        String sqlStr14b = "SELECT mi_idx.info, t.title FROM it1, it2, k, kt, mi, mi_idx, mk, t WHERE it1.info  = 'countries' AND it2.info  = mi_idx.info AND kt.kind  = 'movie' AND kt.id = t.kind_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mi_idx.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id";
        // query 31 a - aciclica
        String sqlStr31a = "SELECT mi.info, mi_idx.info, n.name, t.title FROM ci, cn, it1, it2, k, mc, mi, mi_idx, mk, n, t WHERE  it1.info  = 'genres' AND it2.info  = 'votes' AND n.gender   = 'm' AND t.id = mi.movie_id AND t.id = mi_idx.movie_id AND t.id = ci.movie_id AND t.id = mk.movie_id AND t.id = mc.movie_id AND ci.movie_id = mi.movie_id AND ci.movie_id = mi_idx.movie_id AND ci.movie_id = mk.movie_id AND ci.movie_id = mc.movie_id AND mi.movie_id = mi_idx.movie_id AND mi.movie_id = mk.movie_id AND mi.movie_id = mc.movie_id AND mi_idx.movie_id = mk.movie_id AND mi_idx.movie_id = mc.movie_id AND mk.movie_id = mc.movie_id AND n.id = ci.person_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id AND k.id = mk.keyword_id AND cn.id = mc.company_id";
        // query 21 b - aciclica
        String sqlStr21b = "SELECT cn.name, lt.link, t.title FROM cn, ct, k, lt, mc, mi, mk, ml, t WHERE ct.kind ='production companies' AND k.keyword ='sequel' AND lt.id = ml.link_type_id AND ml.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_type_id = ct.id AND mc.company_id = cn.id AND mi.movie_id = t.id AND ml.movie_id = mk.movie_id AND ml.movie_id = mc.movie_id AND mk.movie_id = mc.movie_id AND ml.movie_id = mi.movie_id AND mk.movie_id = mi.movie_id AND mc.movie_id = mi.movie_id";
        // query 9a - aciclica
        String sqlStr9a = "SELECT an.name, chn.name, t.title FROM an, chn, ci, cn, mc, n, rt, t WHERE  cn.country_code ='[us]' AND n.gender ='f' AND rt.role ='actress' AND ci.movie_id = t.id AND t.id = mc.movie_id AND ci.movie_id = mc.movie_id AND mc.company_id = cn.id AND ci.role_id = rt.id AND n.id = ci.person_id AND chn.id = ci.person_role_id AND an.person_id = n.id AND an.person_id = ci.person_id";
        // query 13d - aciclica
        String sqlStr13d = "SELECT cn.name, miidx.info, t.title FROM cn, ct, it, it2, kt, mc, mi, miidx, t WHERE cn.country_code ='[us]' AND ct.kind ='production companies' AND it.info = miidx.info AND it2.info ='release dates' AND kt.kind ='movie' AND mi.movie_id = t.id AND it2.id = mi.info_type_id AND kt.id = t.kind_id AND mc.movie_id = t.id AND cn.id = mc.company_id AND ct.id = mc.company_type_id AND miidx.movie_id = t.id AND it.id = miidx.info_type_id AND mi.movie_id = miidx.movie_id AND mi.movie_id = mc.movie_id AND miidx.movie_id = mc.movie_id";
        // query 22 c - aciclica
        String sqlStr22c = "SELECT cn.name, mi_idx.info, t.title FROM cn, ct, it1, it2, k, kt, mc, mi, mi_idx, mk, t WHERE it1.info  = 'countries' AND it2.info  = mi_idx.info AND kt.id = t.kind_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mi_idx.movie_id AND t.id = mc.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mi_idx.movie_id AND mk.movie_id = mc.movie_id AND mi.movie_id = mi_idx.movie_id AND mi.movie_id = mc.movie_id AND mc.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id";
        // query 12 a - aciclica
        String sqlStr12a = "SELECT cn.name, mi_idx.info, t.title FROM cn, ct, it1, it2, mc, mi, mi_idx, t WHERE cn.country_code  = '[us]' AND ct.kind  = 'production companies' AND it1.info = 'genres' AND it2.info = mi_idx.info AND t.id = mi.movie_id AND t.id = mi_idx.movie_id AND mi.info_type_id = it1.id AND mi_idx.info_type_id = it2.id AND t.id = mc.movie_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id AND mc.movie_id = mi.movie_id AND mc.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id";
        // query 24 b - aciclica
        String sqlStr24b = "SELECT chn.name, n.name, t.title FROM an, chn, ci, cn, it, k, mc, mi, mk, n, rt, t WHERE cn.country_code ='[us]' AND cn.name  = 'DreamWorks Animation' AND it.info  = 'release dates' AND n.gender ='f'  AND rt.role ='actress' AND t.id = mi.movie_id AND t.id = mc.movie_id AND t.id = ci.movie_id AND t.id = mk.movie_id AND mc.movie_id = ci.movie_id AND mc.movie_id = mi.movie_id AND mc.movie_id = mk.movie_id AND mi.movie_id = ci.movie_id AND mi.movie_id = mk.movie_id AND ci.movie_id = mk.movie_id AND cn.id = mc.company_id AND it.id = mi.info_type_id AND n.id = ci.person_id AND rt.id = ci.role_id AND n.id = an.person_id AND ci.person_id = an.person_id AND chn.id = ci.person_role_id AND k.id = mk.keyword_id";
        // query 20 b - aciclica
        String sqlStr20b = "SELECT t.title FROM cc, cct1, cct2, chn, ci, k, kt, mk, n, t WHERE cct1.kind  = 'cast' AND kt.kind  = 'movie' AND kt.id = t.kind_id AND t.id = mk.movie_id AND t.id = ci.movie_id AND t.id = cc.movie_id AND mk.movie_id = ci.movie_id AND mk.movie_id = cc.movie_id AND ci.movie_id = cc.movie_id AND chn.id = ci.person_role_id AND n.id = ci.person_id AND k.id = mk.keyword_id AND cct1.id = cc.subject_id AND cct2.id = cc.status_id";
        // query 8 d - aciclica
        String sqlStr8d = "SELECT an1.name, t.title FROM an1, ci, cn, mc, n1, rt, t WHERE cn.country_code ='[us]' AND rt.role ='costume designer' AND an1.person_id = n1.id AND n1.id = ci.person_id AND ci.movie_id = t.id AND t.id = mc.movie_id AND mc.company_id = cn.id AND ci.role_id = rt.id AND an1.person_id = ci.person_id AND ci.movie_id = mc.movie_id AND ci.movie_id  in ('movie', 'episode')";
        // query 1 a - aciclica
        String sqlStr1a = "SELECT mc.note, t.title, t.production_year FROM ct, it, mc, mi_idx, t WHERE ct.kind = 'production companies' AND it.info = 'top 250 rank' AND ct.id = mc.company_type_id AND t.id = mc.movie_id AND t.id = mi_idx.movie_id AND mc.movie_id = mi_idx.movie_id AND it.id = mi_idx.info_type_id";
        // query 1 a originale
        String sqlStr1aOrig = "SELECT MIN(mc.note) AS production_note, MIN(t.title) AS movie_title, MIN(t.production_year) AS movie_year FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info_idx AS mi_idx, title AS t WHERE ct.kind = 'production companies' AND it.info = 'top 250 rank' AND mc.note  not like '%(as Metro-Goldwyn-Mayer Pictures)%' and (mc.note like '%(co-production)%' or mc.note like '%(presents)%') AND ct.id = mc.company_type_id AND t.id = mc.movie_id AND t.id = mi_idx.movie_id AND mc.movie_id = mi_idx.movie_id AND it.id = mi_idx.info_type_id";
        // query 2 a originale
        String sqlStr2aOrig = "SELECT MIN(t.id) AS movie_title FROM company_name AS cn, keyword AS k, movie_companies AS mc, movie_keyword AS mk, title AS t WHERE cn.country_code ='[de]' AND k.keyword ='character-name-in-title' AND cn.id = mc.company_id AND mc.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND mc.movie_id = mk.movie_id";
        
        // query 3 a originale - aciclica
        String sqlStr3aOrig = "SELECT MIN(t.title) AS movie_title FROM keyword AS k, movie_info AS mi, movie_keyword AS mk, title AS t WHERE k.keyword  like '%sequel%' AND mi.info  IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German') AND t.production_year > 2005 AND t.id = mi.movie_id AND t.id = mk.movie_id AND mk.movie_id = mi.movie_id AND k.id = mk.keyword_id";
        
        // query 4 a originale
        String sqlStr4aOrig = "SELECT MIN(mi_idx.info) AS rating, MIN(t.title) AS movie_title FROM info_type AS it, keyword AS k, movie_info_idx AS mi_idx, movie_keyword AS mk, title AS t WHERE it.info ='rating' AND k.keyword  like '%sequel%' AND mi_idx.info  > '5.0' AND t.production_year > 2005 AND t.id = mi_idx.movie_id AND t.id = mk.movie_id AND mk.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it.id = mi_idx.info_type_id";
        
        // query 5 a originale
        String sqlStr5aOrig = "SELECT MIN(t.title) AS typical_european_movie FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info AS mi, title AS t WHERE ct.kind  = 'production companies' AND mc.note  like '%(theatrical)%' and mc.note like '%(France)%' AND mi.info  IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German') AND t.production_year > 2005 AND t.id = mi.movie_id AND t.id = mc.movie_id AND mc.movie_id = mi.movie_id AND ct.id = mc.company_type_id AND it.id = mi.info_type_id";
        
        // query 6 a originale - aciclica
        String sqlStr6aOrig = "SELECT MIN(k.keyword) AS movie_keyword, MIN(n.name) AS actor_name, MIN(t.title) AS marvel_movie FROM cast_info AS ci, keyword AS k, movie_keyword AS mk, name AS n, title AS t WHERE k.keyword = 'marvel-cinematic-universe' AND n.name LIKE '%Downey%Robert%' AND t.production_year > 2010 AND k.id = mk.keyword_id AND t.id = mk.movie_id AND t.id = ci.movie_id AND ci.movie_id = mk.movie_id AND n.id = ci.person_id";
        
        // query 7 b originale
        String sqlStr7bOrig = "SELECT MIN(n.name) AS of_person, MIN(t.title) AS biography_movie FROM aka_name AS an, cast_info AS ci, info_type AS it, link_type AS lt, movie_link AS ml, name AS n, person_info AS pi, title AS t WHERE an.name LIKE '%a%' AND it.info ='mini biography' AND lt.link ='features' AND n.name_pcode_cf LIKE 'D%' AND n.gender='m' AND pi.note ='Volker Boehm' AND t.production_year BETWEEN 1980 AND 1984 AND n.id = an.person_id AND n.id = pi.person_id AND ci.person_id = n.id AND t.id = ci.movie_id AND ml.linked_movie_id = t.id AND lt.id = ml.link_type_id AND it.id = pi.info_type_id AND pi.person_id = an.person_id AND pi.person_id = ci.person_id AND an.person_id = ci.person_id AND ci.movie_id = ml.linked_movie_id";
        
        // query 7 a originale
        String sqlStr7aOrig = "SELECT MIN(n.name) AS of_person, MIN(t.title) AS biography_movie FROM aka_name AS an, cast_info AS ci, info_type AS it, link_type AS lt, movie_link AS ml, name AS n, person_info AS pi, title AS t WHERE an.name LIKE '%a%' AND it.info ='mini biography' AND lt.link ='features' AND n.name_pcode_cf BETWEEN 'A' AND 'F' AND (n.gender='m' OR (n.gender = 'f' AND n.name LIKE 'B%')) AND pi.note ='Volker Boehm' AND t.production_year BETWEEN 1980 AND 1995 AND n.id = an.person_id AND n.id = pi.person_id AND ci.person_id = n.id AND t.id = ci.movie_id AND ml.linked_movie_id = t.id AND lt.id = ml.link_type_id AND it.id = pi.info_type_id AND pi.person_id = an.person_id AND pi.person_id = ci.person_id AND an.person_id = ci.person_id AND ci.movie_id = ml.linked_movie_id;";
        
        // query 14 a originale
        String sqlStr14aOrig = "SELECT MIN(mi_idx.info) AS rating, MIN(t.title) AS northern_dark_movie FROM info_type AS it1, info_type AS it2, keyword AS k, kind_type AS kt, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, title AS t WHERE it1.info  = 'countries' AND it2.info  = 'rating' AND k.keyword  in ('murder', 'murder-in-title', 'blood', 'violence') AND kt.kind  = 'movie' AND mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German', 'USA', 'American') AND mi_idx.info  < '8.5' AND t.production_year  > 2010 AND kt.id = t.kind_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mi_idx.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id";
        
        // query 8 a originale
        String sqlStr8aOrig = "SELECT MIN(an1.name) AS actress_pseudonym, MIN(t.title) AS japanese_movie_dubbed FROM aka_name AS an1, cast_info AS ci, company_name AS cn, movie_companies AS mc, name AS n1, role_type AS rt, title AS t WHERE ci.note ='(voice: English version)' AND cn.country_code ='[jp]' AND mc.note like '%(Japan)%' and mc.note not like '%(USA)%' AND n1.name like '%Yo%' and n1.name not like '%Yu%' AND rt.role ='actress' AND an1.person_id = n1.id AND n1.id = ci.person_id AND ci.movie_id = t.id AND t.id = mc.movie_id AND mc.company_id = cn.id AND ci.role_id = rt.id AND an1.person_id = ci.person_id AND ci.movie_id = mc.movie_id;";
        
        // query 9 a originale
        String sqlStr9aOrig = "SELECT MIN(an.name) AS alternative_name, MIN(chn.name) AS character_name, MIN(t.title) AS movie FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, movie_companies AS mc, name AS n, role_type AS rt, title AS t WHERE ci.note  in ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)') AND cn.country_code ='[us]' AND mc.note  is not NULL and (mc.note like '%(USA)%' or mc.note like '%(worldwide)%') AND n.gender ='f' and n.name like '%Ang%' AND rt.role ='actress' AND t.production_year  between 2005 and 2015 AND ci.movie_id = t.id AND t.id = mc.movie_id AND ci.movie_id = mc.movie_id AND mc.company_id = cn.id AND ci.role_id = rt.id AND n.id = ci.person_id AND chn.id = ci.person_role_id AND an.person_id = n.id AND an.person_id = ci.person_id;";
        
        // query 10 a originale
        String sqlStr10aOrig = "SELECT MIN(chn.name) AS uncredited_voiced_character, MIN(t.title) AS russian_movie FROM char_name AS chn, cast_info AS ci, company_name AS cn, company_type AS ct, movie_companies AS mc, role_type AS rt, title AS t WHERE ci.note  like '%(voice)%' and ci.note like '%(uncredited)%' AND cn.country_code  = '[ru]' AND rt.role  = 'actor' AND t.production_year > 2005 AND t.id = mc.movie_id AND t.id = ci.movie_id AND ci.movie_id = mc.movie_id AND chn.id = ci.person_role_id AND rt.id = ci.role_id AND cn.id = mc.company_id AND ct.id = mc.company_type_id";
        
        // query 11 a originale
        String sqlStr11aOrig = "SELECT MIN(cn.name) AS from_company, MIN(lt.link) AS movie_link_type, MIN(t.title) AS non_polish_sequel_movie FROM company_name AS cn, company_type AS ct, keyword AS k, link_type AS lt, movie_companies AS mc, movie_keyword AS mk, movie_link AS ml, title AS t WHERE cn.country_code !='[pl]' AND (cn.name LIKE '%Film%' OR cn.name LIKE '%Warner%') AND ct.kind ='production companies' AND k.keyword ='sequel' AND lt.link LIKE '%follow%' AND mc.note IS NULL AND t.production_year BETWEEN 1950 AND 2000 AND lt.id = ml.link_type_id AND ml.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_type_id = ct.id AND mc.company_id = cn.id AND ml.movie_id = mk.movie_id AND ml.movie_id = mc.movie_id AND mk.movie_id = mc.movie_id;";
        
        // query 12 a originale
        String sqlStr12aOrig = "SELECT MIN(cn.name) AS movie_company, MIN(mi_idx.info) AS rating, MIN(t.title) AS drama_horror_movie FROM company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, title AS t WHERE cn.country_code  = '[us]' AND ct.kind  = 'production companies' AND it1.info = 'genres' AND it2.info = 'rating' AND mi.info  in ('Drama', 'Horror') AND mi_idx.info  > '8.0' AND t.production_year  between 2005 and 2008 AND t.id = mi.movie_id AND t.id = mi_idx.movie_id AND mi.info_type_id = it1.id AND mi_idx.info_type_id = it2.id AND t.id = mc.movie_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id AND mc.movie_id = mi.movie_id AND mc.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id";
        
        // query 13 a originale
        String sqlStr13aOrig = "SELECT MIN(mi.info) AS release_date, MIN(miidx.info) AS rating, MIN(t.title) AS german_movie FROM company_name AS cn, company_type AS ct, info_type AS it, info_type AS it2, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS miidx, title AS t WHERE cn.country_code ='[de]' AND ct.kind ='production companies' AND it.info ='rating' AND it2.info ='release dates' AND kt.kind ='movie' AND mi.movie_id = t.id AND it2.id = mi.info_type_id AND kt.id = t.kind_id AND mc.movie_id = t.id AND cn.id = mc.company_id AND ct.id = mc.company_type_id AND miidx.movie_id = t.id AND it.id = miidx.info_type_id AND mi.movie_id = miidx.movie_id AND mi.movie_id = mc.movie_id AND miidx.movie_id = mc.movie_id";
        
        // query 15 a originale
        String sqlStr15aOrig = "SELECT MIN(mi.info) AS release_date, MIN(t.title) AS internet_movie FROM aka_title AS at, company_name AS cn, company_type AS ct, info_type AS it1, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t WHERE cn.country_code  = '[us]' AND it1.info  = 'release dates' AND mc.note  like '%(200%)%' and mc.note like '%(worldwide)%' AND mi.note  like '%internet%' AND mi.info  like 'USA:% 200%' AND t.production_year  > 2000 AND t.id = at.movie_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mc.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mc.movie_id AND mk.movie_id = at.movie_id AND mi.movie_id = mc.movie_id AND mi.movie_id = at.movie_id AND mc.movie_id = at.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND cn.id = mc.company_id AND ct.id = mc.company_type_id";
        
        // query 16 a originale
        String sqlStr16aOrig = "SELECT MIN(an.name) AS cool_actor_pseudonym, MIN(t.title) AS series_named_after_char FROM aka_name AS an, cast_info AS ci, company_name AS cn, keyword AS k, movie_companies AS mc, movie_keyword AS mk, name AS n, title AS t WHERE cn.country_code ='[us]' AND k.keyword ='character-name-in-title' AND t.episode_nr > 50 AND t.episode_nr < 100 AND an.person_id = n.id AND n.id = ci.person_id AND ci.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_id = cn.id AND an.person_id = ci.person_id AND ci.movie_id = mc.movie_id AND ci.movie_id = mk.movie_id AND mc.movie_id = mk.movie_id";
        
        // query 17 a originale
        String sqlStr17aOrig = "SELECT MIN(n.name) AS member_in_charnamed_american_movie, MIN(n.name) AS a1 FROM cast_info AS ci, company_name AS cn, keyword AS k, movie_companies AS mc, movie_keyword AS mk, name AS n, title AS t WHERE cn.country_code ='[us]' AND k.keyword ='character-name-in-title' AND n.name  LIKE 'B%' AND n.id = ci.person_id AND ci.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_id = cn.id AND ci.movie_id = mc.movie_id AND ci.movie_id = mk.movie_id AND mc.movie_id = mk.movie_id";
        
        // query 18 a originale
        String sqlStr18aOrig = "SELECT MIN(mi.info) AS movie_budget, MIN(mi_idx.info) AS movie_votes, MIN(t.title) AS movie_title FROM cast_info AS ci, info_type AS it1, info_type AS it2, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t WHERE ci.note  in ('(producer)', '(executive producer)') AND it1.info  = 'budget' AND it2.info  = 'votes' AND n.gender  = 'm' and n.name like '%Tim%' AND t.id = mi.movie_id AND t.id = mi_idx.movie_id AND t.id = ci.movie_id AND ci.movie_id = mi.movie_id AND ci.movie_id = mi_idx.movie_id AND mi.movie_id = mi_idx.movie_id AND n.id = ci.person_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id";
        
        // query 19 a originale
        String sqlStr19aOrig = "SELECT MIN(n.name) AS voicing_actress, MIN(t.title) AS voiced_movie FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, info_type AS it, movie_companies AS mc, movie_info AS mi, name AS n, role_type AS rt, title AS t WHERE ci.note  in ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)') AND cn.country_code ='[us]' AND it.info  = 'release dates' AND mc.note  is not NULL and (mc.note like '%(USA)%' or mc.note like '%(worldwide)%') AND mi.info  is not null and (mi.info like 'Japan:%200%' or mi.info like 'USA:%200%') AND n.gender ='f' and n.name like '%Ang%' AND rt.role ='actress' AND t.production_year  between 2005 and 2009 AND t.id = mi.movie_id AND t.id = mc.movie_id AND t.id = ci.movie_id AND mc.movie_id = ci.movie_id AND mc.movie_id = mi.movie_id AND mi.movie_id = ci.movie_id AND cn.id = mc.company_id AND it.id = mi.info_type_id AND n.id = ci.person_id AND rt.id = ci.role_id AND n.id = an.person_id AND ci.person_id = an.person_id AND chn.id = ci.person_role_id";
        
        // query 20 a originale
        String sqlStr20aOrig = "SELECT MIN(t.title) AS complete_downey_ironman_movie FROM complete_cast AS cc, comp_cast_type AS cct1, comp_cast_type AS cct2, char_name AS chn, cast_info AS ci, keyword AS k, kind_type AS kt, movie_keyword AS mk, name AS n, title AS t WHERE cct1.kind  = 'cast' AND cct2.kind  like '%complete%' AND chn.name  not like '%Sherlock%' and (chn.name like '%Tony%Stark%' or chn.name like '%Iron%Man%') AND k.keyword  in ('superhero', 'sequel', 'second-part', 'marvel-comics', 'based-on-comic', 'tv-special', 'fight', 'violence') AND kt.kind  = 'movie' AND t.production_year  > 1950 AND kt.id = t.kind_id AND t.id = mk.movie_id AND t.id = ci.movie_id AND t.id = cc.movie_id AND mk.movie_id = ci.movie_id AND mk.movie_id = cc.movie_id AND ci.movie_id = cc.movie_id AND chn.id = ci.person_role_id AND n.id = ci.person_id AND k.id = mk.keyword_id AND cct1.id = cc.subject_id AND cct2.id = cc.status_id";
        
        // query 21 a originale
        String sqlStr21aOrig = "SELECT MIN(cn.name) AS company_name, MIN(lt.link) AS link_type, MIN(t.title) AS western_follow_up FROM company_name AS cn, company_type AS ct, keyword AS k, link_type AS lt, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, movie_link AS ml, title AS t WHERE cn.country_code !='[pl]' AND (cn.name LIKE '%Film%' OR cn.name LIKE '%Warner%') AND ct.kind ='production companies' AND k.keyword ='sequel' AND lt.link LIKE '%follow%' AND mc.note IS NULL AND mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German') AND t.production_year BETWEEN 1950 AND 2000 AND lt.id = ml.link_type_id AND ml.movie_id = t.id AND t.id = mk.movie_id AND mk.keyword_id = k.id AND t.id = mc.movie_id AND mc.company_type_id = ct.id AND mc.company_id = cn.id AND mi.movie_id = t.id AND ml.movie_id = mk.movie_id AND ml.movie_id = mc.movie_id AND mk.movie_id = mc.movie_id AND ml.movie_id = mi.movie_id AND mk.movie_id = mi.movie_id AND mc.movie_id = mi.movie_id";
        
        // query 22 a originale
        String sqlStr22aOrig = "SELECT MIN(cn.name) AS movie_company, MIN(mi_idx.info) AS rating, MIN(t.title) AS western_violent_movie FROM company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, keyword AS k, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, title AS t WHERE cn.country_code  != '[us]' AND it1.info  = 'countries' AND it2.info  = 'rating' AND k.keyword  in ('murder', 'murder-in-title', 'blood', 'violence') AND kt.kind  in ('movie', 'episode') AND mc.note  not like '%(USA)%' and mc.note like '%(200%)%' AND mi.info IN ('Germany', 'German', 'USA', 'American') AND mi_idx.info  < '7.0' AND t.production_year  > 2008 AND kt.id = t.kind_id AND t.id = mi.movie_id AND t.id = mk.movie_id AND t.id = mi_idx.movie_id AND t.id = mc.movie_id AND mk.movie_id = mi.movie_id AND mk.movie_id = mi_idx.movie_id AND mk.movie_id = mc.movie_id AND mi.movie_id = mi_idx.movie_id AND mi.movie_id = mc.movie_id AND mc.movie_id = mi_idx.movie_id AND k.id = mk.keyword_id AND it1.id = mi.info_type_id AND it2.id = mi_idx.info_type_id AND ct.id = mc.company_type_id AND cn.id = mc.company_id";
        
        // query 32 a originale
        String sqlStr32aOrig = "SELECT MIN(lt.link) AS link_type, MIN(t1.title) AS first_movie, MIN(t2.title) AS second_movie FROM keyword AS k, link_type AS lt, movie_keyword AS mk, movie_link AS ml, title AS t1, title AS t2 WHERE k.keyword ='10,000-mile-club' AND mk.keyword_id = k.id AND t1.id = mk.movie_id AND ml.movie_id = t1.id AND ml.linked_movie_id = t2.id AND lt.id = ml.link_type_id AND mk.movie_id = t1.id";
        
        
        Hypergraph hyper3 = new Hypergraph();
        
        Set e1 = new HashSet();
        e1.add("A");
        e1.add("B");
        e1.add("C");
        
        Set e2 = new HashSet();
        
        e2.add("C");
        e2.add("D");
        e2.add("E");
    
        Set e3 = new HashSet();
        
        e3.add("E");
        e3.add("F");
        e3.add("A");
        
        Set e4 = new HashSet();
        
        e4.add("E");
        e4.add("G");
        
        hyper3.addEdge3(e1);
        hyper3.addEdge3(e2);
        hyper3.addEdge3(e3);
        hyper3.addEdge3(e4);
        
        System.out.println(hyper3.getEdges());
        hyper3.GYOAlgo();
        
        //parseQuery(sqlStr);
        
    }
    
    static public String getBeforeDot (String s) {
        int iend = s.indexOf(".");
        String subString = null;
        if (iend != -1) {
            subString = s.substring(0, iend);
        }
        return subString;
    }
    
    static public String getAfterDot (String s) {
        return s.substring(s.lastIndexOf(".")+1);
    }
    
    static public void popolateHypergraph (ArrayList tabelle, HashMap tabelle_map, Hypergraph hyper) {
        for (Object obj : tabelle) {
                Tabella tab = (Tabella)tabelle_map.get((String)obj);
                tab.printContent();
                hyper.addEdge3(tab.getParentesi());
            }
    }
    
    static public void parseQuery (String sqlStr) throws JSQLParserException {
        Statement statement = CCJSqlParserUtil.parse(sqlStr);
            
            //ArrayList tabelle = new ArrayList();
            ArrayList attributi_select = new ArrayList();
            ArrayList uguaglianze = new ArrayList();
            
            if (statement instanceof Select) {
                Select select = (Select)statement;
                SelectBody selectBody = select.getSelectBody();
                
                List<SelectItem> selectCols = ((PlainSelect) ((Select) select).getSelectBody()).getSelectItems();
                for (SelectItem selectItem : selectCols) {
                    System.out.println("select: "+getInsideParenthesis(selectItem.toString()));
                    attributi_select.add(getInsideParenthesis(selectItem.toString()));
                }
                
                
                
                select.getSelectBody().accept(new SelectVisitorAdapter(){
            @Override
            public void visit(PlainSelect plainSelect) {
                plainSelect.getFromItem().accept(fromVisitor);
                if (plainSelect.getJoins()!=null)
                   plainSelect.getJoins().forEach(join -> join.getRightItem().accept(fromVisitor));
            }
        });
                
                TablesNamesFinder tablesNamesFinder = new TablesNamesFinder();
                List tableList = tablesNamesFinder.getTableList(select);
                for (Iterator iter = tableList.iterator(); iter.hasNext();) {
                    Object table = iter.next();
                    System.out.println("tabella: "+table);
                    //tabelle.add(table);
                }
                
                if (selectBody instanceof PlainSelect) {
                    PlainSelect plainSelect = (PlainSelect)selectBody;
                    Expression whereExpression = plainSelect.getWhere();
                    whereExpression.accept(new ExpressionVisitorAdapter() {
                        @Override
                        protected void visitBinaryExpression (BinaryExpression expr) {
                            if (expr instanceof ComparisonOperator && !expr.getStringExpression().equals("<") && !expr.getStringExpression().equals(">")) {
                                //ArrayList coppia = new ArrayList();
                                Set coppia = new HashSet();
                                System.out.println("left = "+expr.getLeftExpression()+" op: "+expr.getStringExpression()+" right = "+expr.getRightExpression());
                                coppia.add(expr.getLeftExpression().toString());
                                coppia.add(expr.getRightExpression().toString());
                                uguaglianze.add(coppia);
                                
                                if (expr.getLeftExpression() instanceof InExpression) {
                                    InExpression inExpression = (InExpression)expr.getLeftExpression();
                                    System.out.println("trovata!");
                                    LOGGER.log(Level.INFO, "Found IN Expression: {0}", inExpression);
                                }
                                if (expr.getRightExpression() instanceof InExpression) {
                                    InExpression inExpression = (InExpression)expr.getRightExpression();
                                    System.out.println("trovata!");
                                    LOGGER.log(Level.INFO, "Found IN Expression: {0}", inExpression);
                                }
                            }
                            System.out.println("Sinistra: "+expr.getLeftExpression()+", Destra: "+expr.getRightExpression());
                            super.visitBinaryExpression(expr);
                        }
                    });
                    
                    whereExpression.accept(new ExpressionVisitorAdapter() {
                        @Override
                        public void visit(InExpression inExpression) {
                            inExpression.getLeftExpression().accept(this);
                            inExpression.getRightItemsList().accept(this);
                            LOGGER.log(Level.INFO, "Found IN Expression: {0}", inExpression);
                            //inExpression.getItemsList().accept(this);
                        }
                    });
                    
                    whereExpression.accept(new ExpressionVisitorAdapter() {
                        @Override
                        public void visit(LikeExpression likeExpression) {
                            likeExpression.getLeftExpression().accept(this);
                            //likeExpression.getStringExpression();
                            String like = likeExpression.toString();
                            LOGGER.log(Level.INFO, "Found LIKE Expression: {0}", like.toLowerCase());
                            System.out.println("cancella da: "+sqlStr.indexOf(like.toLowerCase())+" a: "+sqlStr.lastIndexOf(like.toLowerCase()));
                            //inExpression.getItemsList().accept(this);
                        }
                    });
                    
                    if (whereExpression instanceof AndExpression) {
                        AndExpression andExpression =(AndExpression)whereExpression;
                        LOGGER.log(Level.INFO, "Found AND Expression: {0}", andExpression);
                        System.out.println(andExpression);
                        Expression leftExpression = andExpression.getLeftExpression();
                        System.out.println(leftExpression);
                    }
                    else if (whereExpression instanceof OrExpression) {
                        OrExpression orExpression = (OrExpression)whereExpression;
                        LOGGER.log(Level.INFO, "Found AND Expression: {0}", orExpression);
                    }
                    else if (whereExpression instanceof InExpression) {
                        InExpression inExpression = (InExpression)whereExpression;
                        LOGGER.log(Level.INFO, "Found IN Expression: {0}", inExpression);
                    }
                }
            }
            // popolo la mappa delle tabelle:
            // questa mappa contiene tutti i nomi
            // delle tabelle che sono state scandite
            // dal parser, in modo che possano essere 
            // recuperate semplicemente usando il
            // loro nome come chiave
            HashMap tabelle_map = new HashMap();
            for (Object obj : tabelle) {
                System.out.println("tabella "+obj);
                Tabella tab = new Tabella((String)obj);
                tabelle_map.put((String)obj, tab);
            }
            // come ho pensato, per il momento lasciamo stare
            // l'inserimento dei caratteri presenti nella Select
            // In fondo, guardiamo solo quelli uguali nella where,
            // e alla fine inseriamo caratteri nuovi alla fine,
            // fino a raggiungere la cardinalità
            
            /*for (Object obj : attributi_select) {
                System.out.println("attributo select: "+obj);
                String tabella_dove_andare = getBeforeDot((String)obj);
                String attributo_da_inserire = getAfterDot((String)obj);
                Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                tab.addAttribute(attributo_da_inserire);
            }*/
            
            System.out.println("le uguaglianze sono: "+uguaglianze);
            for (int i=0; i<uguaglianze.size(); i++) {
                Set set = (Set)uguaglianze.get(i);
                Iterator iter = set.iterator();
                while(iter.hasNext()) {
                    String s = (String)iter.next();
                    if (!s.startsWith("'") && !s.endsWith("'")) {
                        //System.out.println("INSERENDO TUTTI "+s);
                        String tabella_dove_andare = getBeforeDot(s);
                        String attributo_da_inserire = getAfterDot(s);
                        //System.out.println("inserisco attr generale "+attributo_da_inserire);
                        Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                        tab.addAttributoGenerale(attributo_da_inserire);
                    }
                }
            }
            /*ArrayList uguaglianze_sistemate = new ArrayList();
            for (int i=0; i<uguaglianze.size()-1; i++) {
                ArrayList coppia = (ArrayList)uguaglianze.get(i);
                    for (int j=i+1; j<uguaglianze.size(); j++) {
                        ArrayList coppia2 = (ArrayList)uguaglianze.get(j);
                        String attr1 = (String)coppia.get(0);
                        String attr2 = (String)coppia.get(1);
                        String attr3 = (String)coppia2.get(0);
                        String attr4 = (String)coppia2.get(1);
                        if (attr1.equals(attr3) || attr1.equals(attr4) ||
                                attr2.equals(attr3) || attr2.equals(attr4)) {
                            Set insieme_consistent = new HashSet();
                            insieme_consistent.add(coppia.get(0));
                            insieme_consistent.add(coppia.get(1));
                            insieme_consistent.add(coppia2.get(0));
                            insieme_consistent.add(coppia2.get(1));
                            
                            uguaglianze_sistemate.add(insieme_consistent);
                            
                            uguaglianze.remove(uguaglianze.indexOf(coppia));
                            uguaglianze.remove(uguaglianze.indexOf(coppia2));
                            uguaglianze.add(insieme_consistent);
                        }
                    }
            }*/
            //System.out.println("le uguaglianze sistemate sono: "+uguaglianze);
            
            // questa parte serve per riconoscere se ci sono
            // degli attributi equiparati a delle costanti:
            // in caso affermativo, come T.b = 'Marco', 
            // rimuovo questa coppia dalle uguaglianze, e
            // riduco la cardinalità della tabella coinvolta.
            // Così facendo, successivamente non verrà popolata
            // con attributi aggiuntivi
            /*for (int i=0; i<uguaglianze.size(); i++) {
                Set coppia = (Set)uguaglianze.get(i);
                Iterator<String> iter = coppia.iterator();
                String str1 = null;
                String str2 = null;
                while (iter.hasNext()) {
                    str1 = (String)iter.next();
                    str2 = (String)iter.next();
                }
                if (str1.startsWith("'") && str1.endsWith("'")) {
                    String tabella_dove_andare = getBeforeDot(str2);
                    Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                    tab.reduceCardinality();
                    // se, riducendo la cardinalità di 1, 
                    // arrivo a 0, significa che quella tabella aveva
                    // un solo attributo, ed è equiparato a una costante:
                    // significa che non ha alcun attributo rilevante,
                    // quindi posso eliminare questa tabella: per me 
                    // non ha alcuna importanza
                    if (tab.getCardinality() == 0) {
                        tabelle_map.remove(tabella_dove_andare);
                    }
                    uguaglianze.remove(coppia);
                }
                else if (str2.startsWith("'") && str2.endsWith("'")) {
                    String tabella_dove_andare = getBeforeDot(str1);
                    Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                    tab.reduceCardinality();
                    // se, riducendo la cardinalità di 1, 
                    // arrivo a 0, significa che quella tabella aveva
                    // un solo attributo, ed è equiparato a una costante:
                    // significa che non ha alcun attributo rilevante,
                    // quindi posso eliminare questa tabella: per me 
                    // non ha alcuna importanza
                    if (tab.getCardinality() == 0) {
                        tabelle_map.remove(tabella_dove_andare);
                    }
                    uguaglianze.remove(coppia);
                }
            }*/
            
            // questa parte serve per sistemare le uguaglianze,
            // in modo che tutti gli attributi che sono uguali
            // tra loro vengano inseriti nello stesso set
            /*ArrayList uguaglianze_copia1 = new ArrayList(uguaglianze);
            //int dimensione = 0;
            int size = uguaglianze.size();
            boolean continua = true;
            while (continua) {
                for (int i=0; i<uguaglianze.size()-1; i++) {
                    Set coppia1 = (Set)uguaglianze.get(i);
                    //System.out.println("sto guardando: "+coppia1+", pos "+i);
                    for (int j=i+1; j<uguaglianze.size(); j++) {
                        Set coppia2 = (Set)uguaglianze.get(j);
                        //System.out.println("confronto con: "+coppia2+", pos "+j);
                        if (!Collections.disjoint(coppia1, coppia2)) {
                            uguaglianze.remove(coppia1);
                            uguaglianze.remove(coppia2);
                            Set unito = new HashSet();
                            unito.addAll(coppia1);
                            unito.addAll(coppia2);
                            uguaglianze.add(unito);
                            //System.out.println("inserisco la coppia unificata: "+unito);
                        }
                    }
                }
                if (uguaglianze.size() != size) {
                    // se alla fine del giro, trovo che
                    // la dimensione delle uguaglianze è
                    // cambiata, significa che ho apportato
                    // una modifica, e quindi continuo
                    //uguaglianze_copia1.clear(); tieni
                    //uguaglianze_copia1.addAll(uguaglianze); tieni
                    //uguaglianze_copia1 = new ArrayList(uguaglianze);
                    size = uguaglianze.size();
                    //System.out.println("CONTINUO");

                } else if (uguaglianze.size() == size) {
                    continua = false;
                    //uguaglianze_copia1.clear(); tieni
                    //uguaglianze_copia1.addAll(uguaglianze); tieni
                    //uguaglianze_copia1 = new ArrayList(uguaglianze);
                    size = uguaglianze.size();
                }
            }
            //uguaglianze = uguaglianze_copia1;
            //Set set_dummy = new HashSet(uguaglianze);
            //uguaglianze.clear();
            //uguaglianze.addAll(set_dummy);
            System.out.println("le uguaglianze sistemate sono: "+uguaglianze);*/
            
            ArrayList uguaglianze2 = new ArrayList(uguaglianze);
            uguaglianze2 = mergeIntersectingSets(uguaglianze2);
            System.out.println("le uguaglianze sistemate sono: "+uguaglianze2);
            
            // Qui, sistemo una cosa legata alle costanti:
            // se per esempio ho T.b = 'Marco', e poi di seguito
            // ho un attributo, mettiamo R.b, messo uguale a T.b,
            // allora anche R.b è una costante, e quindi non ci interessa.
            // In altre parole, tutti gli attributi che sono costanti,
            // vengono eliminati. 
            
            ArrayList uguaglianze_copia = new ArrayList(uguaglianze2);
            for (int i=0; i<uguaglianze_copia.size(); i++) {
                Set set = (Set)uguaglianze_copia.get(i);
                //System.out.println(set);
                Iterator<String> iter = set.iterator();
                while(iter.hasNext()) {
                    String attributo = (String)iter.next();
                    if (attributo.startsWith("'") && attributo.endsWith("'")) {
                        uguaglianze2.remove(set);
                    }
                }
            }
            
            System.out.println("le uguaglianze sistemate dalle costanti sono: "+uguaglianze2);
            
            // con questa parte, per ogni set di uguaglianze (sistemate),
            // vado a mettere una lettera, che sarà quindi comune a 
            // tutti gli attributi presenti in quel set. In altre
            // parole: attributi uguali tra loro, avranno stessa lettera.
            // Mentre compio questo procedimento, tengo traccia delle lettere 
            // che ho scelto, nel Set charSoFar
            Alfabeto alfa = new Alfabeto();
            Set charSoFar = new HashSet();
            int num = -1;
            for (Object set : uguaglianze2) {
                num++;
                set = (Set)set;
                String lettera = alfa.getLetter(num, charSoFar);
                charSoFar.add(lettera);
                System.out.println("la lettera scelta per "+set+" è: "+lettera);
                for (Object s : (Set)set) {
                    s = (String)s;
                    String tabella_dove_andare = getBeforeDot((String)s);
                    //String attributo_da_inserire = getAfterDot((String)s);
                    Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                    tab.addAttribute(lettera);
                }
            }
            
            ArrayList tabelle_short = new ArrayList();
            for (Object s : tabelle_map.keySet()) {
                tabelle_short.add((String)s);
            }
            
            // quest'ultima parte, serve per aggiungere attributi
            // alle tabelle, che contengono meno attributi 
            // della loro cardinalità: tecnicamente, questi attributi
            // non sono comparsi nel WHERE della query.
            // Devo fare attenzione a non usare lettere prima già impiegate
            // per altri attributi, altrimenti non avrebbe senso: quindi, 
            // prima di inserire la nuova lettera, controllo di non averla
            // già impiegata prima, altrimenti ne genero un'altra
            /*for (Object obj : tabelle) {
                Tabella tab = (Tabella)tabelle_map.get((String)obj);
                //System.out.println(tab.getNome()+": size "+tab.getSize()+", card "+tab.getCardinalità());
                if (tab.getSize() != tab.getCardinalità()) {
                    for (int i=tab.getSize(); i<=tab.getCardinalità()-1; i++) {
                        String lettera = alfa.getLetter(num, charSoFar);
                        charSoFar.add(lettera);
                        //System.out.println(tab.getNome()+" giro e metto "+lettera);
                        tab.addAttribute(lettera);
                        num++;
                    }
                }
            }*/
            
            Hypergraph hyper4 = new Hypergraph();
            popolateHypergraph(tabelle, (HashMap) tabelle_map, hyper4);
            
            /*for (Object obj : tabelle) {
                Tabella tab = (Tabella)tabelle_map.get((String)obj);
                tab.printContent();
                hyper4.addEdge3(tab.getParentesi());
            }*/
            
            HashMap mappa_tabelle_albero = fromEdgestoTab(tabelle, tabelle_map);
            
            System.out.println("");
            System.out.println("SELECT: "+attributi_select);
            for (int i=0; i<attributi_select.size(); i++) {
                String s = (String)attributi_select.get(i);
                String tabella_dove_andare = getBeforeDot((String)s);
                String attributo_da_inserire = getAfterDot((String)s);
                Tabella tab = (Tabella)tabelle_map.get(tabella_dove_andare);
                tab.addSelect(s);
                tab.addAttributoGenerale(getAfterDot(s));
            }
            
            ArrayList results4 = (ArrayList)hyper4.GYOAlgo();
            JoinTree2 join4 = null;
            if (results4 != null) {
                join4 = (JoinTree2)results4.get(1);
                Node root4 = (Node)results4.get(2);
                if (join4 != null && root4 != null) {
                    //join4.postOrder(root4, mappa_tabelle_albero, attributi_select, uguaglianze2);
                }
            }
            
            System.out.println("");
            System.out.println("");
            
            //join4.printNodes();
            ArrayList trees = new ArrayList();
            List<Node> nodi = join4.getNodes();
            for (Node n : nodi) {
                if (n != join4.getRoot()) {
                    JoinTree2 j = new JoinTree2(join4);
                    //System.out.println("ROOT: "+n);
                    JoinTree2 result = Flip(j, j.getRoot(), n);
                    
                    /*HashMap mappa_dummy = new HashMap();
                    for (Object value : tabelle_map.values()) {
                        Tabella t = (Tabella)value;
                        Tabella copia = new Tabella(t.getNome());
                        copia.setAttributiGenerali(t.getAttributi());
                        copia.setParentesi(t.getParentesi());
                        mappa_dummy.put(copia.getNome(), copia);
                    }
                    HashMap mappa_tabelle_albero_dummy = fromEdgestoTab(tabelle, mappa_dummy);
                    result.postOrder(result.getRoot(), mappa_tabelle_albero_dummy, attributi_select, uguaglianze2);*/
                    //System.out.println("IL JOINTREE É:");
                    //result.printNodes();
                    trees.add(result);
                }
            }
                       
            trees.add(join4);
            
            ArrayList queries = new ArrayList();
            
            for (int i=0; i<trees.size(); i++) {
                JoinTree2 join = (JoinTree2)trees.get(i);
                join.printNodes();
                //join.printNodes2();
                HashMap mappa_dummy = new HashMap();
                    for (Object value : tabelle_map.values()) {
                        Tabella t = (Tabella)value;
                        Tabella copia = new Tabella(t.getNome());
                        copia.setAttributiGenerali(t.getAttributi());
                        copia.setParentesi(t.getParentesi());
                        mappa_dummy.put(copia.getNome(), copia);
                        //System.out.println("gli attributi di "+copia.getNome()+" sono: "+copia.getAttributi());
                    }
                HashMap mappa_tabelle_albero_dummy = fromEdgestoTab(tabelle, mappa_dummy);
                ArrayList attributi_select_dummy = new ArrayList(attributi_select);
                String query = join.postOrder(join.getRoot(), mappa_tabelle_albero_dummy, attributi_select_dummy, uguaglianze2);
                queries.add(query);
            }
            
            System.out.println(queries.size());
            JDBC database = new JDBC(queries);
            database.connect();
            
            //for (Node n : join.getNodes()) {
              //  System.out.println("i figli di "+n+" sono: "+n.getChildren());
            //}
            
            /*ArrayList provaMultipli = (ArrayList)hyper4.GYOAlgo2();
            System.out.println("I JOINTREE SONO "+provaMultipli.size());
            for (int i=0; i<provaMultipli.size(); i++) {
                ArrayList albero = (ArrayList)provaMultipli.get(i);
                JoinTree2 join = (JoinTree2)albero.get(1);
                Node root = (Node)albero.get(2);
                if (join != null && root != null) {
                    join.printNodes();
                    ArrayList attributi_select_copia = new ArrayList(attributi_select);
                    //HashMap mappa_tabelle_albero_copia = new HashMap(mappa_tabelle_albero);
                    ArrayList uguaglianze2_copia = new ArrayList(uguaglianze2);
                    //join.postOrder(root, mappa_tabelle_albero, attributi_select_copia, uguaglianze2_copia);
                    
                }
            }*/

            
            /*System.out.println("");
            for (Object value : tabelle_map.values()) {
                Tabella tab = (Tabella)value;
                System.out.println(tab.getNome()+": "+tab.getAttributi());
            }*/
            
    }
    
    static public HashMap fromEdgestoTab (ArrayList tabelle, HashMap tabelle_map) {
        HashMap mappa_tabelle_albero = new HashMap();
        for (int i=0; i<tabelle.size(); i++) {
            String str = (String)tabelle.get(i);
            Tabella tab = (Tabella)tabelle_map.get(str);
            
            System.out.println("inserisco nella mappa "+tab.getParentesi()+" - "+tab.getNome());
            mappa_tabelle_albero.put(tab.getParentesi(), tab);
        }
        return mappa_tabelle_albero;
    }
    
    static public String getInsideParenthesis (String select) {
        return select.substring(select.indexOf('(')+1, select.indexOf(')'));
    }
    
    static public String getAfterAs (String from) {
        return from.substring(from.indexOf("AS")+3);
    }
    
    private final static FromItemVisitorAdapter fromVisitor = new FromItemVisitorAdapter() {
        @Override
        public void visit(SubSelect subSelect) {
            System.out.println("subselect=" + subSelect);
        }

        @Override
        public void visit(Table table) {
            System.out.println("table=" + getAfterAs(table.toString()));
            tabelle.add(getAfterAs(table.toString()));
        }
    };
    
    private static <T> ArrayList<Set<T>> mergeIntersectingSets (Collection<? extends Set<T>> unmergedSets) {
        boolean edited = false;
        
        ArrayList<Set<T>> mergedSets = new ArrayList();
        for (Set<T> subset1 : unmergedSets) {
            boolean merged = false;
            
            for (Set<T> subset2 : mergedSets) {
                if (!Collections.disjoint(subset1, subset2)) {
                    subset2.addAll(subset1);
                    merged = true;
                    edited = true;
                }
            }
            // otherwise, add the current subset as a new subset
            if (!merged) mergedSets.add(subset1);
        }
        
        if (edited) return mergeIntersectingSets(mergedSets); //continue merging until we reach a fixpoint
        else return mergedSets;
    }
    
    public static Node FlipTree (Node root, Node root2) {
        if (root == null) {
            return root;
        }
        FlipTree(root2, null, new Hashtable(), root);
        return root2;
    }
    
    public static void FlipTree (Node current, Node parent, Hashtable processed, Node root) {
        if (current == null) {
            return;
        }
        Node temp = current.getParent();
        current.setParent(parent);
        if (current == root) {
            List<Node> children = current.getChildren();
            for (int i=0; i<children.size(); i++) {
                Node node = (Node)children.get(i);
                if (node != null && processed.containsKey(node.edge)) {
                    node = null;
                }
                if (node != null && !processed.containsKey(node.edge)) {
                    
                }
            }
        }
    }
    
    public static JoinTree2 flipTree (JoinTree2 join, Node root, Node root2) {
        
        Node parent = root2.getParent();
        List<Node> children = root2.getChildren();
        
        ArrayList<Node> connections = new ArrayList();
        if (parent != null) {
            connections.add(parent);
        }
        for (Node n : children) {
            connections.add(n);
        }
        System.out.println("le connessioni di "+root2+" sono: "+connections);
        
        for (int i=0; i<connections.size(); i++) {
            Node node = (Node)connections.get(i);
            root2.addChild(node);
        }
        boolean cont = true;
        Node come_from = root2;
        while (cont) {
            for (int i=0; i<connections.size(); i++) {
                Node node = (Node)connections.get(i);
            
                Node p = node.getParent();
                List<Node> child = node.getChildren();
                ArrayList<Node> conn = new ArrayList();
            
            
                if (p != null && p != come_from) {
                    conn.add(p);
                }
                for (Node n : child) {
                    if (n != come_from) {
                        conn.add(n);
                    }
                }
                for (int j=0; j<conn.size(); j++) {
                    Node agg = (Node)conn.get(j);
                    node.addChild(agg);
                }
            }
        }
        return null;
    }
    
    public static JoinTree2 Flip (JoinTree2 join, Node root, Node root2) {
        if (root == null) {
            return null;
        }
        JoinTree2 join2 = new JoinTree2(join);
        for (Node n : join2.getNodes()) {
            n.setParent(null);
            n.setChildren(new ArrayList());
            n.unVisit();
        }
        FlipRec(root2, null, join2);
        //System.out.println("IL JOINTREE É:");
        //join2.printNodes();
        return join2;
    }
    
    public static void FlipRec (Node node, Node coming_from, JoinTree2 j2) {
        /*if (node.isVisited()) {
            return;
        }*/
        //node.setVisited();
        //System.out.println("sono in Rec con "+node);
        Node parent = node.getParent();
        List<Node> children = node.getChildren();
        
        ArrayList<Node> connections = new ArrayList();
        if (parent != null && parent != coming_from) {
            connections.add(parent);
        }
        for (Node n : children) {
            if (n != coming_from) {
                connections.add(n);
            }
        }
        //System.out.println("le connessioni di "+node+" sono: "+connections);
        
        for (int i=0; i<connections.size(); i++) {
            Node nodo = (Node)connections.get(i);
            Node padre = (Node)j2.getNode(node);
            padre.addChild2(nodo);
            Node child = (Node)j2.getNode(nodo);
            child.setParent(padre);
            //System.out.println("aggiungo a "+padre+" il figlio "+nodo);
        }
        //j2.printNodes();
        //System.out.println("ora "+node+" ha come figli: "+node.getChildren());
        for (int i=0; i<connections.size(); i++) {
            Node x = (Node)connections.get(i);
            //System.out.println("lavoro sul nodo "+x);
            if (!x.isVisited()) {
                FlipRec(x, node, j2);
            }
            //FlipRec(x, node, j2);
        }
    }
}
