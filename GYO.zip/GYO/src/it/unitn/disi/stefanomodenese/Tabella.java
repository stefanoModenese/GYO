/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author stefanomodenese
 */
public class Tabella {
    String nome;
    //HashMap<String, Set> parentesi;
    Set<String> parentesi;
    Set<String> select;
    Set<String> attributi;
    int cardinalità;
    Set<String> comuni;
    boolean visited = false;
    String stringa = "";
    String RName = "";
    Set also_count = new HashSet();
    
    public Tabella (String nome) {
        this.nome = nome;
        this.parentesi = new HashSet();
        //this.parentesi = new HashMap();
        //parentesi.put(nome, new HashSet());
        this.select = new HashSet();
        this.attributi = new HashSet();
        this.cardinalità = 3;
        this.comuni = new HashSet();
        this.RName = nome;
    }
    
    public void resetStatus () {
        this.stringa = "";
        this.RName = this.nome;
        this.also_count = new HashSet();
        this.visited = false;
        this.comuni = new HashSet();
    }
    
    public boolean isVisited () {
        return this.visited;
    }
    
    public void setVisited (int counter) {
        this.visited = true;
        this.RName = produceRName(counter);
    }
    
    public void setStringa (String stringa) {
        this.stringa = stringa;
    }
    
    public String getStringa () {
        return this.stringa;
    }
    
    public Set getParentesi () {
        //return this.parentesi.get(this.nome);
        return this.parentesi;
    }
    
    public void setParentesi (Set<String> parentesi) {
        this.parentesi.addAll(parentesi);
    }
    
    public Set getSelect() {
        return this.select;
    }
    
    public Set getAttributi () {
        return this.attributi;
    }
    
    public Set getAttributiFinali (ArrayList select) {
        Set result = new HashSet();
        ArrayList att = new ArrayList(this.attributi);
        for (int i=0; i<att.size(); i++) {
            String attributo = this.nome+"."+att.get(i);
            for (int j=0; j<select.size(); j++) {
                //System.out.println("confronto "+attributo+" e "+select.get(j));
                if (attributo.equals(select.get(j))) {
                    result.add(att.get(i));
                }
            }
        }
        return result;
    }
    
    public void addAttribute (String att) {
        this.parentesi.add(att);
        //System.out.println(this.nome+" contiene: "+this.parentesi+"");
    }
    
    public void setAttributiGenerali  (Set attributi) {
        this.attributi.addAll(attributi);
    }
    
    public Set getComuni () {
        return this.comuni;
    }
    
    public void addComuni (String attr) {
        this.comuni.add(attr);
    }
    
    public void addSelect (String attr) {
        this.select.add(attr);
    }
    
    public void addAttributoGenerale (String attr) {
        //System.out.println("ho aggiunto "+attr+" alla tabella "+nome);
        this.attributi.add(attr);
        this.also_count.add(attr);
    }
    
    public boolean isContained (String attr) {
        return this.also_count.contains(attr);
    }
    
    public String produceRName (int counter) {
        return "R" + counter;
    }
    
    public boolean contiene (String att) {
        boolean contenuto = false;
        for (String s : this.parentesi) {
            if (s.equals(att)) {
                contenuto = true;
            }
        }
        return contenuto;
    }
    
    public int getSize () {
        return this.parentesi.size();
    }
    
    public int getCardinalità () {
        return this.cardinalità;
    }
    
    public String getNome () {
        return this.nome;
    }
    
    public void printContent () {
        System.out.println(this.nome+" contiene: "+this.parentesi);
    }
    
    public void reduceCardinality () {
        this.cardinalità--;
    }
    
    public int getCardinality () {
        return this.cardinalità;
    }
}
