/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author stefanomodenese
 */
public class Alfabeto {
    public ArrayList lettere;
    
    public Alfabeto () {
        this.lettere = new ArrayList();
        this.populateAlfabeto();
        
    }
    
    private void populateAlfabeto () {
        for (int i=1; i<27; i++) {
            lettere.add(String.valueOf((char)(i+64)));
            lettere.add(String.valueOf((char)(i+96)));
        }
        
        for (int i=1; i<100; i++) {
            lettere.add(this.randomString(8));
        }
    }
    
    public String getLetter (int num, Set set) {
        //return (String)this.lettere.get(num);
        for (int i=0; i<lettere.size(); i++) {
            if (!set.contains(lettere.get(i))) {
                return (String)lettere.get(i);
            }
        }
        return null;
    }
    
    static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    static SecureRandom rnd = new SecureRandom();

String randomString(int len){
   StringBuilder sb = new StringBuilder(len);
   for(int i = 0; i < len; i++)
      sb.append(AB.charAt(rnd.nextInt(AB.length())));
   return sb.toString();
}
}
