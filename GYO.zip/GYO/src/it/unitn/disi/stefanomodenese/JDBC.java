/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.*;
/**
 *
 * @author stefanomodenese
 */
public class JDBC {
    ArrayList queries = new ArrayList();
    double min = 9.9*100*100*100*100*1000;
    String best = "";
    
    public JDBC (ArrayList queries) {
        this.queries = new ArrayList(queries);
        System.out.println("le query sono: "+queries);
    }
    public void connect () {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "postgres")) {
 
            System.out.println("Java JDBC PostgreSQL Example");
            // When this class first attempts to establish a connection, it automatically loads any JDBC 4.0 drivers found within 
            // the class path. Note that your application must manually load any JDBC drivers prior to version 4.0.
//          Class.forName("org.postgresql.Driver"); 
 
            System.out.println("Connected to PostgreSQL database!");
            Statement statement = connection.createStatement();
            Statement local = connection.createStatement();
            local.execute("SET LOCAL join_collapse_limit=1");
            for (int i=0; i<queries.size(); i++) {
                ResultSet rs = statement.executeQuery("EXPLAIN (FORMAT JSON) "+(String)queries.get(i));
            while (rs.next()) {
                //System.out.printf("%-30.30s  %-30.30s%n", rs.getString("title"), resultSet.getString("name"));
                //System.out.println(rs.getString(1));
                String json = rs.getString(1);
                //System.out.println(json);
                //JSONObject obj = new JSONObject(json);
                //JSONArray arr = obj.getJSONArray("Plan");
                JSONArray arr = new JSONArray(json);
                //for (int i=0; i<arr.length(); i++) {
                    JSONObject plan = arr.getJSONObject(0);
                    //System.out.println(plan.toString());
                    //String cost = plan.getString("Total Cost");
                    //System.out.println(cost);
                    String cost = getCost(plan.toString());
                    double number = Double.parseDouble(cost);
                    if (number < min) {
                        best = (String)queries.get(i);
                        min = number;
                    }
                //}
                
            }
            }
            
            System.out.println("la query migliore è: "+best+", con costo "+min);
 
        } /*catch (ClassNotFoundException e) {
            System.out.println("PostgreSQL JDBC driver not found.");
            e.printStackTrace();
        }*/ catch (SQLException e) {
            System.out.println("Connection failure.");
            e.printStackTrace();
        }
    }
    public String getCost (String s) {
        s = s.substring(s.indexOf("Cost") + 6);
        s = s.substring(0, s.indexOf(","));

        System.out.println(s);  
        return s;
    }
}
