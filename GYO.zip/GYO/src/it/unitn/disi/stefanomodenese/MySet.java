/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author stefanomodenese
 */
public class MySet<String> extends HashSet {
    
    int a = 10;
    
    @Override
    public boolean equals (Object o) {
        boolean same = false;
        return (o instanceof MySet && ((MySet)o).a == this.a);
    }
    
    @Override
    public int hashCode () {
        return a;
    }
}
