/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 *
 * @author stefanomodenese
 */
public class JoinTree {
    private Map<Node, List<Node>> adjNodes;
    
    public JoinTree () {
        this.adjNodes = new HashMap();
    }
    
    public void addNode (Node nodo) {
        adjNodes.putIfAbsent(nodo, new ArrayList<>());
    }
    
    public void removeNode (Node nodo) {
        //Node n = new Node(nodo);
        adjNodes.values().stream().forEach(e -> e.remove(nodo));
        adjNodes.remove(nodo);
    }
    
    public void addEdge (Node node1, Node node2) {
        //Node n1 = new Node(node1);
        //Node n2 = new Node(node2);
        adjNodes.get(node1).add(node2);
        adjNodes.get(node2).add(node1);
    }
    
    public void removeEdge (Node node1, Node node2) {
        //Node n1 = new Node(node1);
        //Node n2 = new Node(node2);
        List<Node> en1 = adjNodes.get(node1);
        List<Node> en2 = adjNodes.get(node2);
        if (en1 != null) {
            en1.remove(node2);
        }
        if (en2 != null) {
            en2.remove(node1);
        }
    }
    
    public List<Node> getAdjNodes (Node nodo) {
        return adjNodes.get(nodo);
    }
    
    public Set<Node> BFS (JoinTree join, Node root) {
        LinkedHashSet<Node> visited = new LinkedHashSet();
        Queue<Node> queue = new LinkedList();
        queue.add(root);
        visited.add(root);
        while (!queue.isEmpty()) {
            Node node = queue.poll();
            //System.out.println(node);
            if (node.equals(root)) {
                System.out.println(node+": root");
            }
            else {
                System.out.println(node);
            }
            for (Node n : join.getAdjNodes(node)) {
                if (!visited.contains(n)) {
                    visited.add(n);
                    queue.add((Node) n);
                }
            }
        }
        return visited;
    }
}
