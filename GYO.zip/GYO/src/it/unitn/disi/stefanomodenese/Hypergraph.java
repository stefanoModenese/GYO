/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import edu.uci.ics.jung.graph.util.Graphs;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
/**
 *
 * @author stefanomodenese
 */
public class Hypergraph {
    private Set<String> vertices;
    //private Set<List<String>> edges;
    private ArrayList<List<String>> edges;
    private Map<String, List<String>> adjVertices;
    
    public Hypergraph () {
        this.vertices = new HashSet<>();
        //this.edges = new HashSet<>();
        this.edges = new ArrayList<>();
        this.adjVertices = new HashMap<>();
    }
    
    public void addVertex (String label) {
        //Vertex v = new Vertex(label);
        vertices.add(label);
        adjVertices.putIfAbsent(label, new ArrayList<>());
        //adjVertices.putIfAbsent(label, new HashSet<>());
        //System.out.println("ho aggiunto il vertice "+label+", e la sua lista: "+adjVertices.get(label));
    }
    
    public void removeVertex (String label) {
        //Vertex v = new Vertex(label);
        /*for (int i=0; i<vertices.size(); i++) {
            //Vertex u = vertices.get(i);
            String u = vertices.get(i);
            if (u.equals(label)) {
                vertices.remove(i);
            }
        }*/
        vertices.remove(label);
        adjVertices.values().stream().forEach(e -> e.remove(label));
        adjVertices.remove(label);
    }
    
    public Set getVertices () {
        return this.vertices;
    }
    
    public void addEdge (ArrayList<String> vertici) {
        for (int i=0; i<vertici.size(); i++) {
            String label = vertici.get(i);
            //Vertex v = new Vertex(label);
            //adjVertices.get(v)
            for (String l : vertici) {
                //Vertex x = new Vertex(l);
                if (!(label.equals(l))) {
                    adjVertices.get(label).add(l);
                }
            }
        }
    }
    
    public void addEdge2 (String ... args) {
        ArrayList edge = new ArrayList();
        for (String label : args) {
            edge.add(label);
            //Vertex v = findVertex(label);
            for (String l : args) {
                //Vertex x = new Vertex(l);
                if (!(l.equals(label))) {
                    if (adjVertices.get(label) == null) {
                       List<String> adiacenti = adjVertices.get(label);
                       //System.out.println("ho aggiunto "+l+" come adiacente a "+label);
                    }
                    else {
                        adjVertices.get(label).add(l);
                        List<String> list = Arrays.asList(args);
                        Collections.sort(list);
                        edges.add(list);
                        //System.out.println("ho aggiunto "+l+" come adiacente a "+label);
                    }
                }
            }
        }
    }
    
    public void addEdge3 (Set<String> edge) {
        for (String s : edge) {
            vertices.add(s);
        }
        ArrayList arco = new ArrayList(edge);
        Collections.sort(arco);
        edges.add(arco);
    }
    
    public void removeEdge (ArrayList<String> vertici) {
       
        HashSet set = new HashSet<>();
        for (int i=0; i<vertici.size(); i++) {
            String label = vertici.get(i);
            set.add(label);
            //Vertex v = new Vertex(label);
            List<String> adiacenti = adjVertices.get(label);
            if (adiacenti != null) {
                for (String l : vertici) {
                    //Vertex x = new Vertex(l);
                    if (!(l.equals(label))) {
                        adiacenti.remove(l);
                    }
                }
            }
        }
        if (edges.contains(set)) {
            edges.remove(set);
            System.out.println("edge "+set.toString()+" rimossa");
        }
    }
    
    public void removeEdge2 (String ... args) {
        for (String label : args) {
            Vertex v = new Vertex(label);
            List<String> adiacenti = adjVertices.get(label);
            if (adiacenti != null) {
                for (String l : args) {
                    //Vertex x = new Vertex(l);
                    if (!(l.equals(label))) {
                        adiacenti.remove(l);
                    }
                }
            }
        }
    }
    public List<String> getAdjVertices (String label) {
        List<String> list = (List<String>)adjVertices.get(label);
        Set<String> set = new LinkedHashSet<>();
        set.addAll(list);
        list.clear();
        list.addAll(set);
        return list;
    }
    
    public void printList (List<String> lista) {
        //System.out.println(Arrays.toString(lista.toArray()));
        for (String v : lista) {
            System.out.println(v);
        }
    }
    
    public ArrayList getEdges () {
        return edges;
    }
    
    /*public Vertex findVertex (String label) {
        Vertex trovato = new Vertex("");
        for (int i=0; i<vertices.size(); i++) {
            Vertex u = vertices.get(i);
            if (u.label.equals(label)) {
                trovato = u;
            }
        }
        return trovato;
    }*/
    public List findEar1 () {
        //boolean singleton = true;
        //boolean contenute = true;
        for (List l : edges) {
            for (Object s : l) {
                boolean singleton = true;
                System.out.println("sto controllando se "+s+" è singleton");
                s = (String)s;
                for (List li : edges) {
                    if (!(li.equals(l))) {
                        if (li.contains(s)) {
                            System.out.println(s+" è contenuta in "+li+", non è singleton");
                            singleton = false;
                        }
                    }
                    else {
                        continue;
                    }
                    System.out.println(s+" singleton: "+singleton);
                    for (Object d : l) {
                    if (!singleton) {
                        continue;
                    }
                    boolean contenute = true;
                    d = (String)d;
                    if (!(d.equals(s))) {
                        System.out.println("sto verificando che "+d+" sia in "+li);
                        if (!(li.contains(d))) {
                            contenute = false;
                        }
                        }
                    else {
                        //contenute = false;
                        continue;
                    }
                    if (singleton && contenute) {
                System.out.println(l);
                System.out.println("in questo caso G è "+li);
                return l;
            }
                    }
                }
            }
        }
        System.out.println("nessuna ear trovata");
        return null;
    }
    
    public ArrayList findEar () {
        for (List l : edges) {
            HashMap<String, String> singles = new HashMap();
            for (Object s : l) {
                boolean single = true;
                s = (String)s;
                singles.put((String)s, (String)s);
                for (List li : edges) {
                    if (li.equals(l)) {
                        // salta il confronto la stessa edge
                        continue;
                    }
                    else {
                        if (li.contains(s)) {
                            single = false;
                            singles.remove((String)s);
                        }
                    }
                }
                //System.out.println(s+" è single? "+single);
                System.out.println("la edge "+l+"ha singles? Ne ha "+singles.size());
                if (!singles.isEmpty()) {
                    boolean contenuti = true;
                    System.out.println(l+" è un candidato per essere ear");
                    for (List x : edges) {
                        if (x.equals(l)) {
                            // evito il confronto con la stessa ear
                            continue;
                        }
                        else {
                            System.out.println(x+" può essere G?");
                            for (Object obj : l) {
                                obj = (String)obj;
                                if (obj.equals(s)) {
                                    continue;
                                }
                                else {
                                    if (!(x.contains(obj))) {
                                        //System.out.println(x+" non contiene "+obj);
                                        contenuti = false;
                                    }
                                    else {
                                        //System.out.println(x+" contiene "+obj);
                                    }
                                }
                                //System.out.println(contenuti);
                            }
                            if (contenuti) {
                                //System.out.println("il nodo da eliminare è: "+s);
                                //System.out.println(l+" è una ear");
                                //System.out.println(x+" è G");
                                //return l;
                                ArrayList result = new ArrayList();
                                // ritorno, nell'ordine:
                                // 1) il nodo da eliminare
                                // 2) l'orecchia
                                // 3) G
                                result.add(s);
                                result.add(l);
                                result.add(x);
                                
                                return result;
                            }
                            contenuti = true;
                        }
                    }
                }
            }
        }
        return null;
    }
    
    public ArrayList findEar2 () {
        ArrayList risultati = new ArrayList();
        for (List l : edges) {
            HashMap<String, String> singles = new HashMap();
            List G_caso_speciale = null;
            boolean Tutti = false;
            for (Object s : l) {
                boolean single = true;
                boolean tutti = true;
                s = (String)s;
                singles.put((String)s, (String)s);
                for (List li : edges) {
                    if (li.equals(l)) {
                        // salta il confronto la stessa edge
                        continue;
                    }
                    else {
                        if (li.contains(s)) {
                            single = false;
                            singles.remove((String)s);
                        }
                        
                        if (li.containsAll(l)) {
                            //System.out.println(li+" contiene tutto "+l);
                            Tutti = true;
                            G_caso_speciale = li;
                        }
                    }
                }
                //System.out.println(s+" è single? "+single);
                //System.out.println("la edge "+l+"ha singles? Ne ha "+singles.size());
                /*if (!singles.isEmpty()) {
                    boolean contenuti = true;
                    System.out.println(l+" è un candidato per essere ear");
                    for (List x : edges) {
                        if (x.equals(l)) {
                            // evito il confronto con la stessa ear
                            continue;
                        }
                        else {
                            System.out.println(x+" può essere G?");
                            for (Object obj : l) {
                                obj = (String)obj;
                                if (obj.equals(s)) {
                                    continue;
                                }
                                else {
                                    if (!(x.contains(obj))) {
                                        //System.out.println(x+" non contiene "+obj);
                                        contenuti = false;
                                    }
                                    else {
                                        //System.out.println(x+" contiene "+obj);
                                    }
                                }
                                //System.out.println(contenuti);
                            }
                            if (contenuti) {
                                //System.out.println("il nodo da eliminare è: "+s);
                                //System.out.println(l+" è una ear");
                                //System.out.println(x+" è G");
                                //return l;
                                ArrayList result = new ArrayList();
                                // ritorno, nell'ordine:
                                // 1) il nodo da eliminare
                                // 2) l'orecchia
                                // 3) G
                                result.add(s);
                                result.add(l);
                                result.add(x);
                                
                                return result;
                            }
                            contenuti = true;
                        }
                    }
                }*/
            }
            //System.out.println("la edge "+l+" ha singles? Ne ha "+singles.size());
            //System.out.println("la edge "+l+"è del secondo tipo? "+Tutti);
            if (!singles.isEmpty()) {
                boolean contenuti = true;
                //System.out.println(l+" è un candidato per essere ear");
                for (List x : edges) {
                    if (x.equals(l)) {
                        // evito il confronto con la stessa ear
                        continue;
                    }
                    else {
                        //System.out.println(x+" può essere G?");
                        for (Object obj : l) {
                            obj = (String)obj;
                            if (singles.containsKey((String)obj)) {
                                continue;
                            }
                            else {
                                if (!(x.contains(obj))) {
                                    //System.out.println(x+" non contiene "+obj);
                                    contenuti = false;
                                }
                                else {
                                    //System.out.println(x+" contiene "+obj);
                                }
                            }
                        }
                        if (contenuti) {
                            //System.out.println(x+" è G");
                            ArrayList result = new ArrayList();
                            ArrayList eliminare = new ArrayList();
                            //System.out.println("i nodi da eliminare sono:");
                            for (String key : singles.keySet()) {
                                //System.out.println(key);
                                eliminare.add(key);
                            }
                            //System.out.println(l+" è una ear");
                            //System.out.println(x+" è G");
                            
                            // ritorno, nell'ordine:
                            // 1) i nodi da eliminare
                            // 2) l'orecchia
                            // 3) G
                            
                            result.add(eliminare);
                            result.add(l);
                            result.add(x);
                            
                            return result;
                            //risultati.add(result);
                        }
                        contenuti = true;
                    }
                }
            }
            else if (Tutti) {
                ArrayList result = new ArrayList();
                ArrayList eliminare = new ArrayList();
                //System.out.println("i nodi da eliminare sono:");
                /*for (Object key : l) {
                    //System.out.println(key);
                    eliminare.add(key);
                }*/
                //System.out.println(l+" è una ear del secondo tipo");
                //System.out.println(G_caso_speciale+" è G del secondo tipo");
                            
                // ritorno, nell'ordine:
                // 1) i nodi da eliminare
                // 2) l'orecchia
                // 3) G
                            
                result.add(eliminare);
                result.add(l);
                result.add(G_caso_speciale);
                            
                return result;
                //risultati.add(result);
            }
        }
        return null;
        //return risultati;
    }
    
    public ArrayList findEarRicopiataaaaa () {
        ArrayList risultati = new ArrayList();
        for (List l : edges) {
            HashMap<String, String> singles = new HashMap();
            List G_caso_speciale = null;
            boolean Tutti = false;
            for (Object s : l) {
                boolean single = true;
                boolean tutti = true;
                s = (String)s;
                singles.put((String)s, (String)s);
                for (List li : edges) {
                    if (li.equals(l)) {
                        // salta il confronto la stessa edge
                        continue;
                    }
                    else {
                        if (li.contains(s)) {
                            single = false;
                            singles.remove((String)s);
                        }
                        
                        if (li.containsAll(l)) {
                            //System.out.println(li+" contiene tutto "+l);
                            Tutti = true;
                            G_caso_speciale = li;
                        }
                    }
                }
            }
            if (!singles.isEmpty()) {
                boolean contenuti = true;
                //System.out.println(l+" è un candidato per essere ear");
                for (List x : edges) {
                    if (x.equals(l)) {
                        // evito il confronto con la stessa ear
                        continue;
                    }
                    else {
                        //System.out.println(x+" può essere G?");
                        for (Object obj : l) {
                            obj = (String)obj;
                            if (singles.containsKey((String)obj)) {
                                continue;
                            }
                            else {
                                if (!(x.contains(obj))) {
                                    //System.out.println(x+" non contiene "+obj);
                                    contenuti = false;
                                }
                                else {
                                    //System.out.println(x+" contiene "+obj);
                                }
                            }
                        }
                        if (contenuti) {
                            //System.out.println(x+" è G");
                            ArrayList result = new ArrayList();
                            ArrayList eliminare = new ArrayList();
                            //System.out.println("i nodi da eliminare sono:");
                            for (String key : singles.keySet()) {
                                eliminare.add(key);
                            }
                            //System.out.println(l+" è una ear");
                            //System.out.println(x+" è G");
                            
                            // ritorno, nell'ordine:
                            // 1) i nodi da eliminare
                            // 2) l'orecchia
                            // 3) G
                            
                            result.add(eliminare);
                            result.add(l);
                            result.add(x);
                            
                            return result;
                        }
                        contenuti = true;
                    }
                }
            }
            else if (Tutti) {
                ArrayList result = new ArrayList();
                ArrayList eliminare = new ArrayList();
                //System.out.println("i nodi da eliminare sono:");
                /*for (Object key : l) {
                    //System.out.println(key);
                    eliminare.add(key);
                }*/
                //System.out.println(l+" è una ear del secondo tipo");
                //System.out.println(G_caso_speciale+" è G del secondo tipo");
                            
                // ritorno, nell'ordine:
                // 1) i nodi da eliminare
                // 2) l'orecchia
                // 3) G
                            
                result.add(eliminare);
                result.add(l);
                result.add(G_caso_speciale);
                            
                return result;
            }
        }
        return null;
    }
    
    public ArrayList findEarMultiple () {
        ArrayList risultati = new ArrayList();
        for (List l : edges) {
            HashMap<String, String> singles = new HashMap();
            List G_caso_speciale = null;
            boolean Tutti = false;
            for (Object s : l) {
                boolean single = true;
                boolean tutti = true;
                s = (String)s;
                singles.put((String)s, (String)s);
                for (List li : edges) {
                    if (li.equals(l)) {
                        // salta il confronto la stessa edge
                        continue;
                    }
                    else {
                        if (li.contains(s)) {
                            single = false;
                            singles.remove((String)s);
                        }
                        
                        if (li.containsAll(l)) {
                            //System.out.println(li+" contiene tutto "+l);
                            Tutti = true;
                            G_caso_speciale = li;
                        }
                    }
                }
                //System.out.println(s+" è single? "+single);
                //System.out.println("la edge "+l+"ha singles? Ne ha "+singles.size());
                /*if (!singles.isEmpty()) {
                    boolean contenuti = true;
                    System.out.println(l+" è un candidato per essere ear");
                    for (List x : edges) {
                        if (x.equals(l)) {
                            // evito il confronto con la stessa ear
                            continue;
                        }
                        else {
                            System.out.println(x+" può essere G?");
                            for (Object obj : l) {
                                obj = (String)obj;
                                if (obj.equals(s)) {
                                    continue;
                                }
                                else {
                                    if (!(x.contains(obj))) {
                                        //System.out.println(x+" non contiene "+obj);
                                        contenuti = false;
                                    }
                                    else {
                                        //System.out.println(x+" contiene "+obj);
                                    }
                                }
                                //System.out.println(contenuti);
                            }
                            if (contenuti) {
                                //System.out.println("il nodo da eliminare è: "+s);
                                //System.out.println(l+" è una ear");
                                //System.out.println(x+" è G");
                                //return l;
                                ArrayList result = new ArrayList();
                                // ritorno, nell'ordine:
                                // 1) il nodo da eliminare
                                // 2) l'orecchia
                                // 3) G
                                result.add(s);
                                result.add(l);
                                result.add(x);
                                
                                return result;
                            }
                            contenuti = true;
                        }
                    }
                }*/
            }
            //System.out.println("la edge "+l+" ha singles? Ne ha "+singles.size());
            //System.out.println("la edge "+l+"è del secondo tipo? "+Tutti);
            if (!singles.isEmpty()) {
                boolean contenuti = true;
                //System.out.println(l+" è un candidato per essere ear");
                for (List x : edges) {
                    if (x.equals(l)) {
                        // evito il confronto con la stessa ear
                        continue;
                    }
                    else {
                        //System.out.println(x+" può essere G?");
                        for (Object obj : l) {
                            obj = (String)obj;
                            if (singles.containsKey((String)obj)) {
                                continue;
                            }
                            else {
                                if (!(x.contains(obj))) {
                                    //System.out.println(x+" non contiene "+obj);
                                    contenuti = false;
                                }
                                else {
                                    //System.out.println(x+" contiene "+obj);
                                }
                            }
                        }
                        if (contenuti) {
                            //System.out.println(x+" è G");
                            ArrayList result = new ArrayList();
                            ArrayList eliminare = new ArrayList();
                            //System.out.println("i nodi da eliminare sono:");
                            for (String key : singles.keySet()) {
                                //System.out.println(key);
                                eliminare.add(key);
                            }
                            //System.out.println(l+" è una ear");
                            //System.out.println(x+" è G");
                            
                            // ritorno, nell'ordine:
                            // 1) i nodi da eliminare
                            // 2) l'orecchia
                            // 3) G
                            
                            result.add(eliminare);
                            result.add(l);
                            result.add(x);
                            
                            //return result;
                            risultati.add(result);
                        }
                        contenuti = true;
                    }
                }
            }
            else if (Tutti) {
                ArrayList result = new ArrayList();
                ArrayList eliminare = new ArrayList();
                //System.out.println("i nodi da eliminare sono:");
                /*for (Object key : l) {
                    //System.out.println(key);
                    eliminare.add(key);
                }*/
                //System.out.println(l+" è una ear del secondo tipo");
                //System.out.println(G_caso_speciale+" è G del secondo tipo");
                            
                // ritorno, nell'ordine:
                // 1) i nodi da eliminare
                // 2) l'orecchia
                // 3) G
                            
                result.add(eliminare);
                result.add(l);
                result.add(G_caso_speciale);
                            
                //return result;
                risultati.add(result);
            }
        }
        //return null;
        return risultati;
    }
    
    public ArrayList GYOAlgo () {
        //System.out.println("ARCHI: "+edges);
        JoinTree join = new JoinTree();
        Node root = null;
        for (List l : edges) {
            Node nodo = new Node(l);
            join.addNode(nodo);
        }
        JoinTree2 join2 = new JoinTree2();
        /*for (Object obj : tabelle_map.values()) {
            Tabella tab = (Tabella)obj;
            List<String> parentesi = new ArrayList<String>(tab.getParentesi());
            Node nodo = new Node(parentesi, tab);
            join2.addNode(nodo);
        }*/
        for (List l : edges) {
            Node nodo = new Node(l);
            join2.addNode(nodo);
        }
        //prendo lista 
        while(findEar2() != null) {
            ArrayList result = (ArrayList)findEar2();
            List orecchia = (List)result.get(1);
            List G = (List)result.get(2);
            Node nodo1 = new Node(orecchia);
            Node nodo2 = new Node(G);
            join.addEdge(nodo1, nodo2);
            
            Node parent = join2.getNode(nodo2);
            System.out.println("setto "+parent+" come parent di "+join2.getNode(nodo1));
            parent.addChild(join2.getNode(nodo1));
            
            System.out.println("Orecchia individuata: "+orecchia+", con G = "+G);
            System.out.println("rimuovo la edge "+orecchia);
            edges.remove(orecchia);
            //String vertice = (String)result.get(0);
            //removeVertex(vertice);
            ArrayList eliminare = (ArrayList)result.get(0);
            for (Object s : eliminare) {
                System.out.println("rimuovo "+s);
                removeVertex((String)s);
            }
        }
        if (edges.size() == 1) {
            ArrayList to_remove = new ArrayList();
                for (List l : edges) {
                    System.out.println("è rimasta solo "+l+", la rimuovo");
                    //edges.remove(l);
                    to_remove.add(l);
                    root = new Node(l);
                    //System.out.println(root);
                    for (Object s : l) {
                        this.removeVertex((String) s);
                    }
                }
                edges.removeAll(to_remove);
            }
        join2.printNodes();
        if (edges.isEmpty()) {
            System.out.println("l'ipergrafo è aciclico");
            ArrayList finale = new ArrayList();
            finale.add(true);
            finale.add(join2);
            //finale.add(root);
            finale.add(join2.getRoot());
            return finale;
            //return true;
        }
        else {
            System.out.println("l'ipergrafo è ciclico");
            ArrayList finale = new ArrayList();
            finale.add(false);
            finale.add(join2);
            //finale.add(root);
            finale.add(join2.getRoot());
            return finale;
            //return false;
        }
    }
    
    public ArrayList GYOAlgo2 () {
        ArrayList alberi = new ArrayList();
        //System.out.println("ARCHI: "+edges);
        JoinTree join = new JoinTree();
        Node root = null;
        for (List l : edges) {
            Node nodo = new Node(l);
            join.addNode(nodo);
        }
        JoinTree2 join2 = new JoinTree2();
        /*for (Object obj : tabelle_map.values()) {
            Tabella tab = (Tabella)obj;
            List<String> parentesi = new ArrayList<String>(tab.getParentesi());
            Node nodo = new Node(parentesi, tab);
            join2.addNode(nodo);
        }*/
        for (List l : edges) {
            Node nodo = new Node(l);
            join2.addNode(nodo);
        }
        ArrayList<List<String>> archi_copia = new ArrayList<List<String>>(edges);
        Set<String> vertici_copia = new HashSet<String>(vertices);
        ArrayList orecchie = findEarMultiple();
        for (int i=0; i<orecchie.size(); i++) {
            JoinTree2 albero = new JoinTree2();
            for (List l : archi_copia) {
                Node nodo = new Node(l);
                albero.addNode(nodo);
            }
            ArrayList result = (ArrayList)orecchie.get(i);
            List orecchia = (List)result.get(1);
            List G = (List)result.get(2);
            System.out.println("PROVO LA STRADA "+orecchia);
            Node nodo1 = new Node(orecchia);
            Node nodo2 = new Node(G);
            
            //albero.printNodes();
            Node parent = albero.getNode(nodo2);
            System.out.println("setto "+parent+" come parent di "+albero.getNode(nodo1));
            parent.addChild(albero.getNode(nodo1));
            
            System.out.println("Orecchia individuata: "+orecchia+", con G = "+G);
            System.out.println("rimuovo la edge "+orecchia);
            edges.remove(orecchia);
            
            ArrayList eliminare = (ArrayList)result.get(0);
            for (Object s : eliminare) {
                System.out.println("rimuovo "+s);
                removeVertex((String)s);
            }
            //prendo lista 
        while(findEar2() != null) {
            ArrayList result2 = (ArrayList)findEar2();
            List orecchia2 = (List)result2.get(1);
            List G2 = (List)result2.get(2);
            Node nodo1_ = new Node(orecchia2);
            Node nodo2_ = new Node(G2);
            join.addEdge(nodo1_, nodo2_);
            
            Node parent_ = albero.getNode(nodo2_);
            System.out.println("setto "+parent_+" come parent di "+albero.getNode(nodo1_));
            parent_.addChild(albero.getNode(nodo1_));
            
            System.out.println("Orecchia individuata: "+orecchia2+", con G = "+G2);
            System.out.println("rimuovo la edge "+orecchia2);
            edges.remove(orecchia2);
            //String vertice = (String)result.get(0);
            //removeVertex(vertice);
            ArrayList eliminare2 = (ArrayList)result2.get(0);
            for (Object s : eliminare2) {
                System.out.println("rimuovo "+s);
                removeVertex((String)s);
            }
        }
        if (edges.size() == 1) {
            ArrayList to_remove = new ArrayList();
                for (List l : edges) {
                    System.out.println("è rimasta solo "+l+", la rimuovo");
                    //edges.remove(l);
                    to_remove.add(l);
                    root = new Node(l);
                    //System.out.println(root);
                    for (Object s : l) {
                        this.removeVertex((String) s);
                    }
                }
                edges.removeAll(to_remove);
            }
        albero.printNodes();
        if (edges.isEmpty()) {
            System.out.println("l'ipergrafo è aciclico");
            ArrayList finale = new ArrayList();
            finale.add(true);
            finale.add(albero);
            //finale.add(root);
            finale.add(albero.getRoot());
            //return finale;
            alberi.add(finale);
            //return true;
        }
        else {
            System.out.println("l'ipergrafo è ciclico");
            ArrayList finale = new ArrayList();
            finale.add(false);
            finale.add(albero);
            //finale.add(root);
            finale.add(albero.getRoot());
            //return finale;
            alberi.add(finale);
            //return false;
        }
        System.out.println("SISTEMO PER PROSSIMO GIRO");
        vertices.clear();
        vertices.addAll(vertici_copia);
        edges.clear();
        edges.addAll(archi_copia);
        }
        return alberi;
    }
    
}