/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author stefanomodenese
 */
public class Node {
    public List<String> edge = new ArrayList();
    public Tabella tab = new Tabella("new");
    private List<Node> children = new ArrayList();
    private Node parent = null;
    private boolean visited = false;
    
    
    public Node (List<String> edge) {
        this.edge = edge;
    }
    public Node (List<String> edge, Tabella tab) {
        this.edge = edge;
        this.tab = tab;
    }
    
    public Node (List<String> edge, Node parent) {
        this.edge = edge;
        this.parent = parent;
    }
    
    public Node (String ... args) {
        for (String s : args) {
            this.edge.add(s);
        }
    }
    
    public List<Node> getChildren () {
        return children;
    }
    
    public void setChildren (List<Node> children) {
        this.children = children;
    }
    
    public void setParent (Node parent) {
        //parent.addChild(this);
        this.parent = parent;
    }
    
    public void addChild (List<String> edge) {
        Node child = new Node(edge);
        child.setParent(this);
        this.children.add(child);
    }
    
    public void addChild (Node child) {
        child.setParent(this);
        this.children.add(child);
        //System.out.println("ora "+this.toString()+" ha questi figli: "+children);
        //System.out.println("HO AGGIUNTO "+child.toString()+" COME FIGLIO DI "+this.toString());
    }
    
    public void addChild2 (Node child) {
        this.children.add(child);
    }
    
    public List<String> getNode () {
        return this.edge;
    }
    
    public void setNode (List<String> edge) {
        this.edge = edge;
    }
    
    public Tabella getTabella (HashMap mappa_albero) {
        return (Tabella)mappa_albero.get(new HashSet<String>(this.edge));
    }
    
    public boolean isRoot () {
        return (this.parent == null);
    }
    
    public boolean isLeaf () {
        return this.children.size() == 0;
    }
    
    public void removeParent () {
        this.parent = null;
    }
    
    public Node getParent () {
        return this.parent;
    }
    
    public boolean isVisited () {
        return this.visited;
    }
    
    public void setVisited () {
        this.visited = true;
    }
    
    public void unVisit () {
        this.visited = false;
    }
    
    @Override
    public boolean equals (Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        
        Node node = (Node)obj;
        //System.out.println("i due nodi sono: "+node.edge.equals(this.edge));
        return (node.edge.equals(this.edge));
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + Objects.hashCode(this.edge);
        return hash;
    }
    
    @Override
    public String toString () {
        return this.edge.toString();
    }
}
