/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.stefanomodenese;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import org.apache.commons.collections15.multimap.MultiHashMap;

/**
 *
 * @author stefanomodenese
 */
public class JoinTree2 {
    private List<Node> nodes;
    private HashMap realNames;
    private int R_counter = 1;
    
    public JoinTree2 () {
        this.nodes = new ArrayList();
        this.realNames = new HashMap();
        realNames.put("an", "aka_name");
        realNames.put("at", "aka_title");
        realNames.put("ci", "cast_info");
        realNames.put("chn", "char_name");
        realNames.put("cct", "comp_cast_type");
        realNames.put("cct1", "comp_cast_type");
        realNames.put("cct2", "comp_cast_type");
        realNames.put("cn", "company_name");
        realNames.put("ct", "company_type");
        realNames.put("cc", "complete_cast");
        realNames.put("it", "info_type");
        realNames.put("it1", "info_type");
        realNames.put("it2", "info_type");
        realNames.put("k", "keyword");
        realNames.put("kt", "kind_type");
        realNames.put("lt", "link_type");
        realNames.put("mc", "movie_companies");
        realNames.put("mi_idx", "movie_info_idx");
        realNames.put("miidx", "movie_info_idx");
        realNames.put("mi", "movie_info");
        realNames.put("mk", "movie_keyword");
        realNames.put("ml", "movie_link");
        realNames.put("n", "name");
        realNames.put("rt", "role_type");
        realNames.put("t", "title");
        realNames.put("t1", "title");
        realNames.put("t2", "title");
    }
    
    public JoinTree2 (JoinTree2 j) {
        //this.nodes = j.nodes;
        this.nodes = new ArrayList();
        for (Node n : j.getNodes()) {
            Node x = new Node(n.edge);
            this.nodes.add(x);
        }
        this.realNames = j.realNames;
        this.R_counter = j.R_counter;
    }
    
    public void addNode (Node node) {
        nodes.add(node);
    }
    
    public void printNodes () {
        System.out.println("i nodi sono:");
        //System.out.println(nodes);
        for (Node n : nodes) {
            System.out.println(n+" : "+n.getParent()+" padre");
        }
    }
    
    public void printNodes2 () {
        System.out.println("i nodi sono: ");
        for (Node n : nodes) {
            System.out.println(n+" : "+n.getChildren()+" figli");
        }
    }
    
    public Node getNode (Node nodo) {
        for (Node n : nodes) {
            if (n.equals(nodo)) {
                return n;
            }
        }
        return null;
    }
    
    public List<Node> getNodes () {
        return this.nodes;
    }
    
    public Node getRoot () {
        for (Node n : nodes) {
            if (n.isRoot()) {
                return n;
            }
        }
        return null;
    }
    
    public String postOrder (Node root, HashMap mappa, ArrayList select, ArrayList uguaglianze) {
        
        //System.out.println("comincio la visita");
        // return if the tree is empty
        if (root == null) {
            return null;
        }
        
        // create an empty stack and push the root node
        Stack<Node> stack = new Stack<>();
        stack.push(root);
        
        // create another stack to store postorder traversal
        Stack out = new Stack<>();
        
        // loop till stack is empty
        while (!stack.empty())
        {
            // pop a node from the stack and push the data into the output stack
            Node curr = stack.pop();
            Node nod = this.getNode(curr);
            //out.push(new HashSet<String>(curr.edge));
            out.push(nod);
            
            List<Node> children = nod.getChildren();
            //System.out.println("i figli di "+nod+" sono: "+children);
            // push all children of the popped node into the stack
            for (Node n : children) {
                if (n != null) {
                    stack.push(n);
                }
            }
        }
        
        //System.out.println(out);
        
        Tabella last = new Tabella("last");
        String finale = null;
        // print postorder traversal
        while (!out.empty()) {
            //Tabella tab = (Tabella)mappa.get(out.pop());
            Node node = (Node)out.pop();
            Tabella tab = node.getTabella(mappa);
            //Tabella tab = node.tab;
            Node parent = node.getParent();
            Tabella tab2 = new Tabella("nessuno");
            if (parent != null) {
                tab2 = parent.getTabella(mappa);
                //tab2 = parent.tab;
            }
            //System.out.println(tab.getNome() + " unito a: "+tab2.getNome());
            //System.out.println(out.size());
            //ArrayList aggiungere = checkSelect(tab2, select);
            if (!tab2.getNome().equals("nessuno")) {
                if (out.size() != 1) {
                    tab2.setStringa(produceString(tab2.getAttributi(), tab, tab2, 
                    findComuni(tab, tab2, uguaglianze), select));
                    tab2.setVisited(R_counter);
                    R_counter++;
                }
                else {
                    //System.out.println("gli attributi finali sono: "+tab2.getAttributiFinali(select));
                    //System.out.println("la select è: "+select);
                    tab2.setStringa(produceString(tab2.getAttributiFinali(select), tab, tab2,
                            findComuni(tab, tab2, uguaglianze), select));
                    tab2.setVisited(R_counter);
                    R_counter++;
                }
            }
            else {
                finale = tab.getStringa();
            }
        }
        System.out.println(finale);
        return finale;
        /*System.out.println(finale.substring(0, finale.indexOf("FROM")));
        String prima_parte = finale.substring(0, finale.indexOf("FROM"));
        System.out.println(finale.replace(prima_parte, ""));
        
        String fix = null;
        fix = fix + "SELECT ";*/
    }
    
    public String produceString (Set attributes, Tabella tab1, Tabella tab2, ArrayList comuni,
            ArrayList select) {
        ArrayList attributi = new ArrayList(attributes);
        ArrayList aggiungere = checkSelect(tab1, select);
        //System.out.println("attributi aggiuntivi: "+aggiungere);
        String stringa = "SELECT DISTINCT ";
        for (int i=0; i<attributi.size(); i++) {
            String attr = (String)attributi.get(i);
            //System.out.println(attr);
            if (tab2.isVisited()) {
                //attr = replaceR(attr, tab2);
                attr = tab2.RName + "."+attr;
            }
            else {
                attr = tab2.getNome() + "." + attr;
            }
            if (i != attributi.size()-1) {
                //stringa = stringa + tab2.getNome() + "." + attr + ", ";
                stringa = stringa + attr + ", ";
            }
            else {
                //stringa = stringa + tab2.getNome() + "." + attr + " ";
                if (!aggiungere.isEmpty()) {
                    stringa = stringa + attr + ", ";
                    for (int j=0; j<aggiungere.size(); j++) {
                        String plus = (String)aggiungere.get(j);
                        if (j != aggiungere.size()-1) {
                            stringa = stringa + tab1.RName + "." + plus + ", ";
                        }
                        else {
                            stringa = stringa + tab1.RName + "." + plus + " ";
                        }
                        tab2.addAttributoGenerale(plus);
                        select.add( tab2.getNome()+"."+plus);
                    }
                }
                else {
                    stringa = stringa + attr + " ";
                }
            }
        }
        if (attributi.isEmpty() && !aggiungere.isEmpty()) {
            for (int j=0; j<aggiungere.size(); j++) {
                String plus = (String)aggiungere.get(j);
                if (j != aggiungere.size()-1) {
                    stringa = stringa + tab1.RName + "." + plus +", ";
                }
                else {
                    stringa = stringa + tab1.RName + "." + plus + " ";
                }
                tab2.addAttributoGenerale(plus);
                select.add(tab2.getNome()+"."+plus);
            }
        }
        stringa = stringa + "FROM ";
        if (tab2.isVisited()) {
            stringa = stringa + "(" + tab2.getStringa() + ") AS " + tab2.RName + ", ";
        }
        else {
            //stringa = stringa + tab2.getNome() + " AS " + realNames.get(tab2.getNome()) + ", ";
            stringa = stringa + realNames.get(tab2.getNome()) + " AS " + tab2.getNome() + ", ";
        }
        
        if (tab1.isVisited()) {
            stringa = stringa + "(" + tab1.getStringa() + ") AS " + tab1.RName + " ";
        }
        else {
            //stringa = stringa + tab1.getNome() + " AS " + realNames.get(tab1.getNome()) + " ";
            stringa = stringa + realNames.get(tab1.getNome()) + " AS " + tab1.getNome() + " ";
        }
        //stringa = stringa + tab1.getNome() + " AS "+realNames.get(tab1.getNome()) + " , " + tab2.getNome() + " AS "+realNames.get(tab2.getNome()) + " ";
        
        stringa += "WHERE ";
        String dummy = (String)comuni.get(0);
        for (int i=1; i<comuni.size(); i++) {
            if (i == comuni.size()-1) {
                String attr = (String)comuni.get(i);
                stringa = stringa + dummy + " = " + attr;
            }
            else {
                String attr = (String)comuni.get(i);
                stringa = stringa + dummy + " = " + (String)comuni.get(i) + " AND ";
            }
        }
        //System.out.println("la stringa è: "+stringa);
        //tab2.setVisited(R_counter); 
        //R_counter++;
        return stringa;
    }
    
    public ArrayList findComuni (Tabella tab1, Tabella tab2, ArrayList uguaglianze) {
        
        Set<String> set_trovato = new HashSet();
        
        for (int i=0; i<uguaglianze.size(); i++) {
            Set<String> set = (Set<String>)uguaglianze.get(i);
            boolean isTab1 = false;
            boolean isTab2 = false;
            for (String s : set) {
                if (getBeforeDot(s).equals(tab1.getNome())) {
                    isTab1 = true;
                }
                if (getBeforeDot(s).equals(tab2.getNome())) {
                    isTab2 = true;
                }
            }
            if (isTab1 && isTab2) {
                set_trovato = new HashSet(set);
            }
        }
        
        ArrayList values_to_remove = new ArrayList();
        ArrayList values_to_add = new ArrayList();
        
        for (String s : set_trovato) {
            if (!getBeforeDot(s).equals(tab1.getNome()) && !getBeforeDot(s).equals(tab2.getNome())) {
                //System.out.println("RIMUOVO "+s);
                //set_trovato.remove(s);
                values_to_remove.add(s);
            }
            if (getBeforeDot(s).equals(tab1.getNome())) {
                    values_to_remove.add(s);
                    s = replaceR(s, tab1);
                    //System.out.println("modificato in: "+s);
                    values_to_add.add(s);
                }
                else if (getBeforeDot(s).equals(tab2.getNome())) {
                    values_to_remove.add(s);
                    s = replaceR(s, tab2);
                    //System.out.println("modificato in: "+s);
                    values_to_add.add(s);
                }
        }
        
        set_trovato.removeAll(values_to_remove);
        set_trovato.addAll(values_to_add);
        
        //System.out.println("il set comune è: "+set_trovato);
        return new ArrayList(set_trovato);
    }
    
    public String getBeforeDot (String s) {
        int iend = s.indexOf(".");
        String subString = null;
        if (iend != -1) {
            subString = s.substring(0, iend);
        }
        return subString;
    }
    
    public String getAfterDot (String s) {
        return s.substring(s.lastIndexOf(".")+1);
    }
    
    public String replaceR (String s, Tabella tab) {
        int dot = s.indexOf(".");
        //System.out.println("indice del punto: "+dot);
        String substringa = s.substring(0, dot);
        String res = s.replace(substringa, tab.RName);
        
        //System.out.println("sostituisco "+s+" con "+res);
        return res;
    }
    
    public String replaceComuniR (String s, Tabella tab1, Tabella tab2) {
        String beforeDot = getBeforeDot(s);
        if (beforeDot.equals(tab1.getNome())) {
            return replaceR(s, tab1);
        }
        if (beforeDot.equals(tab2.getNome())) {
            return replaceR(s, tab2);
        }
        return null;
    }
    
    public ArrayList checkSelect (Tabella tab, ArrayList select) {
        ArrayList aggiungere = new ArrayList();
        ArrayList attr_to_add = new ArrayList();
        //System.out.println("il select è: "+select+", e la tabella è: "+tab.getNome());
        for (int i=0; i<select.size(); i++) {
            String attr = (String)select.get(i);
            String sub = null;
            if (getBeforeDot(attr).equals(tab.getNome())) {
                //tab.addAttribute(attr);
                int dot = attr.indexOf(".");
                String substringa = attr.substring(dot+1, attr.length());
                //System.out.println("devo aggiungere "+substringa);
                aggiungere.add(substringa);
                sub = substringa;
            }
        }
        select.addAll(attr_to_add);
        return aggiungere;
    }
    
    public void removeSuperflui (Tabella tab, ArrayList select) {
        Set set = new HashSet(select);
        Set s = (Set)tab.getAttributi();
        ArrayList attributi = new ArrayList(s);
        ArrayList attr_da_rimuovere = new ArrayList();
        
        for (int i=0; i<attributi.size(); i++) {
            String attr = (String)attributi.get(i);
            if (!set.contains(tab.getNome()+"."+attr)) {
                attr_da_rimuovere.add(tab.getNome()+"."+attr);
            }
        }
        attributi.removeAll(attr_da_rimuovere);
    }
}
